
pre: size > 0

bool array_max(int[] A, int size) {

	i = 0;
	max = A[0];
	
pc_1:
	while (i < size) {

		if(A[i] > max)
			max = A[i];

		i++;
	}

pc2:

}

post: \forall y1. 0 <= y1 < size => max >= A[y1] 

