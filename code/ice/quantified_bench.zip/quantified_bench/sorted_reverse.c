
pre: \forall y1 y2. 0 <= y1 <= y2 < size => A[y1] <= A[y2]

void array_find(int[] A, int size) {

	index = 0;
        rindex = size - 1;

	while (index < rindex)
        {
		int t = A[index];
		A[index] = A[rindex];
		A[rindex] = t;
		index++;
		rindex--;
        }

}

post: \forall y1 y2. 0 <= y1 <= y2 < size => A[y1] >= A[y2]

