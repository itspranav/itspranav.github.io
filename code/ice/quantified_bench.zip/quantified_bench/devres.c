
pre: size > 0

int devres(int[] tbl, int size, int addr) {

	i = 0;
	
pc_1:
	while (i < size) {

		if(tbl[i] == addr) {
			tbl[i] = 0;
			ret = 1;
			goto pc2;
		}

		i++;
	}
	ret = 0;
pc2:

}

post: (ret = 0 && (\forall y1. 0 <= y1 < size => tbl[y1] != addr)) || (ret = 1 && tbl[i] = 0)

