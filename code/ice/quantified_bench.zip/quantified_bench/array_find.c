
pre: size > 0

bool array_copy(int[] A, int[] B, int size) {

	i = 0;
	
pc_1:
	while (i < size) {

		if(A[i] == key)
			ret = i;
			goto pc2;

		i++;
	}

	ret = size;
pc2:

}

post: \forall y1. 0 <= y1 < ret => A[y1] != key 

