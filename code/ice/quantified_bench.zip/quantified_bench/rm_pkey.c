
pre: size > 0

int rmpkey(int[] pk, int[] pkr, int size, int key) {

	i = 0;
	ret = 0;

pc_1:
	while (i < size) {

		if(pk[i] == key) {
			pkr[i] = pkr[i] - 1;

			if(pkr[i] == 0)
				ret = 1;
			else
				ret = 0;
		
			goto pc2;
		}

		i++;
	}
	ret = 0;
pc2:

}

post: /* In SMT-LIB format */
(or 
        (and (= ret 1) (= (pk i) key) (= (pkr i) 0))
        (and (= ret 0) (= (pk i) key) (not (= (pkr i) 0)))
        (and (= ret 0) (forall ((y1 Int)) (implies (and (<= 0 y1) (< y1 size)) (not (= (pk y1) key)))))

)
