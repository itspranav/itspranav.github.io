
pre: size > 0

bool array_copy(int[] A, int[] B, int size) {

	index = 0;
	iter = 0;
	
pc_1:
	while (iter < size) {

		if(B[iter] < key) {

			A[index] = B[iter];
			index++;
		}

		iter++;
	}

pc2:

}

post: \forall y1. 0 <= y1 < index => A[y1] < key 

