
pre: sizeA > 0 

bool array_copy(int[] A, int sizeA) {

	i = 0;
	
pc_1:
	while (i < sizeA) {

		A[i] = 0;
		i++;
	}
	
	i = 0;
pc2:
	while (i < sizeA) {

		A[i] = A[i] + 2;
		i++;
	}

pc3:
}

post: \forall y1. 0 <= y1 < sizeA => A[y1] <= 4 

