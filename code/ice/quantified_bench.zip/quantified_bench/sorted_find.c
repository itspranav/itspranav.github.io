
pre: size > 0 and \forall y1 y2. 0 <= y1 <= y2 < size => A[y1] <= A[y2]

bool array_find(int[] A, int size, int key) {

	i = 0;
pc_1:
	while (i < size && A[i] < key)
		i++
pc_2:
	if(i >= size)
		ret = 0;
		goto pc_3;

	else if(A[i] > key)
		ret = 0;
		goto pc_3;

	else ret = 1;
pc_3:

}

post: \forall y1 y2. 0 <= y1 <= y2 < size => A[y1] <= A[y2] and
      ((ret = 0 and \forall y3. 0 <= y3 < size => A[y3] != key) or
       (ret = 1 and i < size and A[i] = key and \forall y4. 0 <= y4 < i => A[y4] != key))

