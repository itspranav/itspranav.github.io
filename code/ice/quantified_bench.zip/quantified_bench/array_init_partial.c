
pre: sizeA > 0 && 0 <= Index < sizeA && key > 0

bool array_copy(int[] A, int sizeA, int Index, int key) {

	i = 0;
	
pc_1:
	while (i < sizeA) {

		A[i] = 0;
		i++;
	}

pc2:
	i = Index;
	while (i < sizeA) {

		A[i] = key;
		i++;
	}

pc3:
}

post: \forall y1. 0 <= y1 < sizeA => A[y1] <= key

