
pre: size > 0

bool array_init(int[] A, int size) {

	i = 0;
	
pc_1:
	while (i < size) {

		A[i] = key;
		i++;
	}

pc2:

}

post: \forall y1. 0 <= y1 < size => A[y1] = key 

