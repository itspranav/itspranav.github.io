
pre: size > 0

bool array_compare(int[] A, int[] B, int size) {

	i = 0;
	
pc_1:
	while (i < size) {

		if(A[i] < B[i])
			ret = 1;
			goto pc2;

		else if (A[i] > B[i])
			ret = -1;
			goto pc2;

		i++;
	}

	ret = 0;
pc2:

}

post: \forall y1. 0 <= y1 < i and y1 < size => A[y1] == B[y1] and
      ret = 0 => i >= size and
      ret = 1 => index < size and A[i] < B[i] and
      ret = -1 => index < size and A[i] > B[i] 

