
pre: size > 0 and \forall y1 y2. 1 <= y1 <= y2 < size => A[y1] <= A[y2]
void sorted_insert(int A[], int size) {


        int index = 1;
        int outer = 0;
        int key = A[outer];
        
        while (index < size && A[index] < key) {
        
        	A[outer] = A[index];
        	index++;
        	outer++;
        
        }

        A[outer] = key;
}
        
post: \forall y1 y2. 0 <= y1 <= y2 < size => A[y1] <= A[y2]

