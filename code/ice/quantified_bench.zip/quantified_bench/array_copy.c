
pre: size > 0

bool array_copy(int[] A, int[] B, int size) {

	i = 0;
	
pc_1:
	while (i < size) {

		B[i] = A[i];
		i++;
	}

pc2:

}

post: \forall y1. 0 <= y1 < size => A[y1] == B[y1] 

