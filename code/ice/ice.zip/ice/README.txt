1. Command to enable ICE learning on "program.bpl":
   > Boogie.exe /nologo /noinfer /contractInfer /ice /printAssignment /trace program.bpl

   a) The flag /ice enables ICE learning.
   b) The flag /printAssignment prints out the learnt invariant at the end of the analysis.
   c) The flag /trace prints the statistics and other useful information pertaining to 
      learning.
IMPORTANT: Please give the above flags in the same order as specified.

2. The binaries work only on Windows x86 platform.

3. If you are getting VCOMP100.dll not found error when Boogie tries to run Z3, 
   then install Microsoft Visual C++ 2010 Redistributable Package (x86) from 
   http://www.microsoft.com/downloads/en/details.aspx?FamilyID=a7b7a05e-6de6-4d3a-a423-37bf0912db84

4 Please read the accompanying License file MSPL.txt