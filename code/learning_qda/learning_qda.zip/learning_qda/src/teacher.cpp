#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <list>
#include <string>
#include <set>
#include <utility>
#include <map>
#include <algorithm>

#include <time.h>
#include <ctime>

#include "assert.h"
#include "types.h"
#include "teacher.h"
#include "learner.h"
#include "tools.h"

#include "libalf/conjecture.h"

std::string fileName = "";

/*
 Collect the Statistics
 */
unsigned int num_mem_queries = 0;
unsigned int num_eq_queries = 0;


// A vector of strings to store the data formulas in the considered abstract lattice.
std::vector<std::string> data_formulas;

/* A map from the variable strings to integer. Helps in transforming 
 * the symbolic words into words over integers. 
 * The reverse map helps in the visualization method.
 */

std::map<std::string, unsigned int> variables_to_int;
std::map<unsigned int, std::string> int_to_variables;

/* A map from the set of variable already encoded as integers to the integer alphabet. 
 * Helps in determining the alphabet size which is now no longer 2^(variabes). 
 * Only those sets of variables appear in this map which occur in the data base file of the example. 
 * The reverse map helps in the visualization method.
 */
std::map<std::set<unsigned int>, unsigned int> alphabet_to_int;
std::map<unsigned int, std::set<unsigned int> > int_to_alphabet;


/**
 * Generates a Graphviz DOT visualization of a given Moore machine, which outputs formulas.
 *
 * @param machine The Moore machine to visualize
 * @param formula_names A vector of strings that contains the formulas
 *
 * @return Returns a Graphviz DOT visualization of a given Moore machine.
 */
std::string print(const libalf::moore_machine<type> & machine, const std::vector<std::string> & formula_names) {

	assert(machine.is_valid());

	// Define some variables
	std::stringstream out;
	std::map<std::vector<bool> , int> legend;

	// Index data formulas
	for(std::map<int, type>::const_iterator it=machine.output_mapping.begin(); it!=machine.output_mapping.end(); it++) {
		/* Assumes that the machine is stripped of error states. */
		assert(it->second.ptr != NULL);
		if(legend.count(it->second.ptr->d_type) == 0) {
			unsigned int next = legend.size();
			legend[it->second.ptr->d_type] = next;
		}
	}
	
	// Sanetize formula names
	std::vector<std::string> sanetized_formula_names;
	for(std::vector<std::string>::const_iterator it=formula_names.begin(); it!=formula_names.end(); it++) {
	
		std::string str = *it;
	
		// Replace <
		size_t index = 0;
		while (true) {
			// Locate the substring to replace. /
			index = str.find("<", index);
			if (index == std::string::npos) break;

			/* Make the replacement. */
			str = str.substr(0, index) + "&lt;" + str.substr(index+1, str.size());

			/* Advance index forward one spot so the next iteration doesn't pick it up as well. */
			++index;
		}
		
		// Replace >
		index = 0;
		while (true) {
			// Locate the substring to replace. /
			index = str.find(">", index);
			if (index == std::string::npos) break;

			/* Make the replacement. */
			str = str.substr(0, index) + "&gt;" + str.substr(index+1, str.size());

			/* Advance index forward one spot so the next iteration doesn't pick it up as well. */
			++index;
		}
		
		sanetized_formula_names.push_back(str);
	}

	
	// Header
	out << "digraph moore_machine {" << std::endl;
	//out << "\trankdir=LR;" << std::endl;
	out << "\tsubgraph cluster_automaton {" << std::endl;

	
	/*
	 * States
	 */
	for(int q=0; q<machine.state_count; q++) {
		
		out << "\t\t" << q << " [shape=\"box\", ";
		
		// Initial state
		if(machine.initial_states.count(q) > 0) {
			//out << "color=\"green\", ";
		}

		out << "label=\"q" << q << "; ";

		// Output type
		if(machine.output_mapping.count(q) > 0) {
			
			std::map<int, type>::const_iterator it = machine.output_mapping.find(q);
			
			// Error type
			if(it->second == type::error_type()) {
				out << "Error type";
			}
			
			// NULL pointer
			else if(it->second.ptr == NULL) {
				out << "NULL";
			}
			
			// Normal type
			else {

				// Output data type
				out << legend[it->second.ptr->d_type] << "\"";
			
			}

			out << ", color=\"black\"];";
			
		}
		
		// error
		else {
			out << "NO TYPE\", color=\"red\"];";
		}
		
		out << std::endl;
	}
	
	// Transitions
	for(std::map<int, std::map<int, std::set<int> > >::const_iterator it1=machine.transitions.begin(); it1!=machine.transitions.end(); it1++) {
		for(std::map<int, std::set<int> >::const_iterator it2=it1->second.begin(); it2!=it1->second.end(); it2++) {
			for(std::set<int>::const_iterator it3=it2->second.begin(); it3!=it2->second.end(); it3++) {
			
				out << "\t\t" << it1->first << " -> " << *it3 << " [label=<";
				
				// Decode the label
				assert(int_to_alphabet.count(it2->first) > 0);
                               	std::set<unsigned int> vars = int_to_alphabet.find(it2->first)->second;

                               	// Print the variables occuring together in the label
				for(std::set<unsigned int>::iterator set_it = vars.begin(); set_it != vars.end(); set_it++) {
                                	out << int_to_variables[*set_it] << "<br/>";
                               	}                       
                               	out << ">];" << std::endl;
			
			}
		}
	}
	out << "\t}" << std::endl;

	/*
	 * Legend
	 */
	out << "\tsubgraph cluster_legend {" << std::endl;
	// Sort legend
	std::vector<bool> sorted_legend[legend.size()];
	for(std::map<std::vector<bool>, int>::const_iterator it=legend.begin(); it!=legend.end(); it++) {
		sorted_legend[it->second] = it->first;
	}
	out << "\t\tlegend [shape=\"none\", margin=0, label=<<TABLE BORDER=\"0\">";
	for(unsigned int i=0; i<legend.size(); i++) {

		out << "<TR><TD>" << i << "</TD><TD>";
	
		// Incomplete y_type?!?
		if(sorted_legend[i].size() == 0) { 
			out << "No data type";
		}
		
		else {
		
			assert(sorted_legend[i].size() == (2 * sanetized_formula_names.size()));
			
			// Decode data type
			for(unsigned int j=0; j<sanetized_formula_names.size(); j++) {

				if (sorted_legend[i][2*j] && sorted_legend[i][2*j+1]) {
					; // data_type = 11 (Top)
			
				} else if (sorted_legend[i][2*j] && !sorted_legend[i][2*j+1]) {
					out << " (" << sanetized_formula_names[j].c_str() << ")";
					// data_type = 10 (True)

				} else if (!sorted_legend[i][2*j] && sorted_legend[i][2*j+1]) {
					out << " !(" << sanetized_formula_names[j].c_str() << ")";
					// data_type = 01 (False)
				
				} else if (!sorted_legend[i][2*j] && !sorted_legend[i][2*j+1]) {
					; 
					// data_type = 00 (Bot)
  
				} 
		
			}
			
		}

		out << "</TD></TR>";
	}
	out << "</TABLE>>];" << std::endl;
	out << "\t}" << std::endl;
	
	out << "\tlegend -> 0 [style=\"invis\"];" << std::endl;
	
	// Footer
	out << "}";
	
	return out.str();
}

/**
 * Implementation of the teacher.
 *
 * This class implements a teacher as described in Section 7 of the paper.
 * The teacher reads example.data which forms the knowledge-base of the teacher.
 * This file is obtained by instrumenting the example with several input lists/arrays.
 * The membership queries and equivalence queries are then answered completely
 * automatically using the knowledge base as explained in Section 7.
 *
 * @author Daniel Neider
 * @version 1.0
 */
class test_teacher : public teacher {

	//private:
	public:
	
	/*
	 * Stores the alphabet size used by the teacher.
	 */
	unsigned int alphabet_size;

	/*
	 * Maps the symbolic words constructed from the accepted strings to their corresponding y_types and data_types.
	   Is a multi-map since there might be repeated symbolic words.
	 */
	std::multimap<std::list<int>, type> accepted_samples;

	/*
	 * Stores the moore machine (prefix-tree) constructed from the accepted strings.
	 * Used by the teacher as the concept to learn. Uses this for answering membership/equivalence queries.
	 */
	libalf::moore_machine<type> concept_moore_machine;

	public:

	/**
	 * Constructs a deterministic Moore machine that is consistent with the given
	 * sample words, i.e., whose output for the given samples matches the type of
	 * the corresponding sample. Initializes the data-member <tt>concept_moore_machine</tt>
	 * with the constructed moore machine.
  	 * 
	 * The output of this machine on words that are not contained in the samples
	 * is always a default type. This default type can be given as a parameter
	 * <tt>default_type</tt>. If this parameter is not given, we use the error_type,
	 * i.e., <tt>type::error_type()</tt>.
	 *
	 * @param samples The samples to derive a Moore machine from
	 * @param default_type The default output symbol for words that are not
	 *                     contained in the sample.
	 *
	 */
	void init_concept_moore_machine(const std::multimap<std::list<int>, type> & samples, const type default_type = type::error_type()) {

		// Define some variables we are going to need
		int alphabet_size = 1;
		unsigned int state_count = 1;
		std::map<int, std::map<int, std::set<int> > > transitions;
		std::set<int> initial;
		std::map<int, type> output_mapping;
	
		// Initial state is state 0
		// y_type of empty word is the empty set.
		initial.insert(0);
		output_mapping[0] = type(abstract_type());
	
		// Create prefix tree by considering each individual word from the sample
		for(std::multimap<std::list<int>, type>::const_iterator set_it=samples.begin(); set_it!=samples.end(); set_it++) {
			
			int current_state = 0;
			// used for incrementally calculating the y_type as the word is read.
			#ifdef SIMPLE_Y_TYPE
			std::set<unsigned int> y_type;
			#else
			std::set<unsigned int> y_type;
			#endif

			// Check for every symbol of the input word whether there already exists
			// a transition to go. If not, insert a new state and a new transition.
			for(std::list<int>::const_iterator word_it=set_it->first.begin(); word_it!=set_it->first.end(); word_it++) {
		
				// Check input symbol
				if(*word_it < 0)  {
					std::cerr << "Encountered invalid input symbol (<0)" << std::endl;
					continue;
				}

				if(*word_it >= alphabet_size) {
					alphabet_size = *word_it+1;
				}
			
				assert(int_to_alphabet.count(*word_it) > 0);	
				std::set<unsigned int> variable_alphabet = int_to_alphabet.find(*word_it)->second;
				
				#ifdef SIMPLE_Y_TYPE
				if(variable_alphabet.size() != 0) {
					for(std::set<unsigned int>::iterator it = variable_alphabet.begin(); it != variable_alphabet.end(); it++) {
						y_type.insert(*it);
					}
				}
				#else
				if(variable_alphabet.size() != 0) {
                                       	y_type.insert(*word_it);
                               	}
				#endif
	
				std::set<int> dest = transitions[current_state][*word_it];
		
				// There is no such transition. Therefore, we need to create a new state
				if(dest.size()==0) {
		
					/* Create new state, an internal node with default (empty) data_type irrespective
					 * of the symbol.
					 */
					output_mapping[state_count] = type(abstract_type(y_type));
					state_count++;
				
					// Create new transition
					transitions[current_state][*word_it].insert(state_count-1);
				
					current_state = state_count-1;

				}
			
				// There exists a transition, hence, traverse it
				else if(dest.size()==1) {
					current_state = *(dest.begin());
				}
			
				// There is nondeterminism (which should never happen!)
				else {
					std::cerr << "Nondeterminism detected!" << std::endl;
					exit(1);
				}
			
			}
		
			type result = type(abstract_type());
			simple_test_join().join(output_mapping[current_state], set_it->second, result);		
			output_mapping[current_state] = result;
		}
	
		// Initialize the data-member concept_moore_machine
		concept_moore_machine.input_alphabet_size = alphabet_size;
		concept_moore_machine.state_count = state_count+1;
		concept_moore_machine.transitions = transitions;
		concept_moore_machine.initial_states = initial;
		concept_moore_machine.output_mapping = output_mapping;
		concept_moore_machine.is_deterministic = true;
		concept_moore_machine.valid = true;

		return;	
	}


	/*
	 * Parses and initializes sample of words consistent with the data base of 
	 * accepted strings, specified in the file <tt>fileName</tt>.
	 * Also initializes global data structures variables_to_int and data_formulas.
	 * The data member alphabet_size is also initialized.
 
	 * @param fileName The name of the file with the data base of the accepting strings.
	 */
	void init_accepted_samples_from_file(std::string fileName) {

		std::string line;
		std::ifstream myfile (fileName.c_str());
		if(myfile.is_open()) {
			while(!myfile.eof()) {
				getline(myfile, line);

				// if the line is empty, continue reading the next line.
				if (line.size() == 0) 
					continue;

				/* Check if the line encodes a data_formula
				 * Extract the data_formula and push it into the vector<std::string> data_formulas.
				 */
				if(line.compare(0, 13, "data_formula:") == 0) {
					line.replace(0, 13, "");
					// Each string encoding a data formula terminates in "."
					size_t pos = line.find(".", 0);
					if (pos != std::string::npos) {
						data_formulas.push_back(line.substr(0, pos));						

					} else {
						std::cerr << "Error in file " << fileName << ".data" << std::endl;
						std::cerr << "Data formula does not terminate with character \".\"" << std::endl;
						exit(0);
					}
					continue;
				}


				/* Check if the line encodes a pointer variable or a universal variable.
				 * Extract the variable string and the corresponding integer. Push the mapping 
				 * into the map<std::string, int> variables_to_int.
				 */
				if(line.compare(0, 9, "variable:") == 0) {
					line.replace(0, 9, "");
					size_t pos = line.find(":", 0);
					if (pos != std::string::npos) {
						std::string variable = line.substr(0, pos);
						line.replace(0, pos+1, "");
						// Each string encoding a pointer/universal variable terminates in "."
						pos = line.find(".", 0);
						if(pos != std::string::npos) {
							unsigned int variable_value;
							std::stringstream convert(line.substr(0, pos));
		                                        convert >> variable_value;

							variables_to_int.insert( std::pair<std::string, unsigned int>(variable, variable_value) );
							int_to_variables.insert( std::pair<unsigned int, std::string>(variable_value, variable) );

						} else {
							std::cerr << "Error in file " << fileName << ".data" << std::endl;
							std::cerr << "Variable string does not terminate with character \".\"" << std::endl;
							exit(0);
						}

					} else {
						std::cerr << "Error in file " << fileName << ".data" << std::endl;
						std::cerr << "Variable string missing character \":\"" << std::endl;
						exit(0);
					}
					continue;
				}
	


				/* Check if the line encodes a formula string.
				 * Extract the formula string and insert it into the data member "accepted samples".
				 */
				if(line.compare(0, 7, "string:") == 0) {
					line.replace(0, 7, "");
						
					// word to be constructed from the accepted string encoded in <tt>line</tt>
					std::list<int> word;
					std::vector<bool> dataType;

					#ifdef SIMPLE_Y_TYPE
					// y_type = set of vars seen till now
					std::set<unsigned int> y_type;
					#else
					// y_type = set of alphabets (where alphabet encodes the set of vars)
					std::set<unsigned int> y_type;
					#endif

					// the symbolic word has been read and the data type is to be read now.
					while(line.at(0) != ':') {

						if (line.at(0) != '{')
						{
							std::cerr << "Error in file " << fileName << ".data" << std::endl;
							std::cerr << "Formula string missing character \"{\" in line: "  << line << std::endl;
							exit(0);
						}
						line.replace(0, 1, "");

						/* Construct the integer alphabet by extracting one variable at a time from the string. */
						unsigned int alphabet = 0; 
						std::set<unsigned int> variable_alphabet;

						while(line.at(0) != '}') {
							size_t pos = line.find(" ", 0);
							if(pos != std::string::npos) {
								// Extract the variable at the start of the symbolic word
								std::string variable = line.substr(0, pos);
								//std::cout << "variable not present in variables_to_count: " << variable << std::endl;
								assert(variables_to_int.count(variable) > 0);

								#ifdef SIMPLE_Y_TYPE
								y_type.insert(variables_to_int.find(variable)->second);
								#endif

								variable_alphabet.insert(variables_to_int.find(variable)->second);
								line.replace(0, pos+1, "");
								continue;

							} else {
								std::cerr << "Error in file " << fileName << ".data" << std::endl;
								std::cerr << "Formula string missing space after variable name in line: "  << line;
								std::cerr << std::endl;
								exit(0);
							}
						}
						line.replace(0, 1, "");

						if(alphabet_to_int.count(variable_alphabet) > 0) {
							alphabet = alphabet_to_int.find(variable_alphabet)->second;

						} else {
							alphabet = alphabet_size;
							alphabet_to_int.insert(std::make_pair(variable_alphabet, alphabet));
							int_to_alphabet.insert(std::make_pair(alphabet, variable_alphabet));
							alphabet_size++;

						}
						word.push_back(alphabet);

						#ifndef SIMPLE_Y_TYPE
						// alphabet is not the blank symbol
						if(variable_alphabet.size() != 0) {
                                                       	y_type.insert(alphabet);
                                               		//std::cout << "    ";
						}
						#endif
					}
					line.replace(0, 1, "");

					// Construct the data type from the string of 0's and 1's.
					std::stringstream convert(line);
					char ch;
					while (convert.get(ch)) {
						if(ch == '0')
							dataType.push_back(false);
						else if (ch == '1') 
							dataType.push_back(true);
					}

					/* Insert the word and its y_type and data_type into samples. */
					accepted_samples.insert(std::pair<std::list<int>,type>(word, type(abstract_type(y_type, dataType))));
				}

			}

		} else {
			std::cout << "Error: Unable to open file " << fileName << std::endl;
			exit(1);
		}
		
		myfile.close();
	
		return;

	}

	/**
	 * Creates a new test teacher for the given alphabet size (which defaults to 0).
	 * Intializes accepted_samples by strings read from <tt>fileName</tt> which is 
	 * initialized in the main method.
	 * Also initializes concept_moore_machine by the Moore machine which accepts all the
	 * accepted_samples.
	 *
	 * @param alphabet_size The size of the alphabet used by the teacher
	 */
	test_teacher(unsigned int alphabet_size = 0) : alphabet_size(alphabet_size) {

		init_accepted_samples_from_file(fileName);
		init_concept_moore_machine(accepted_samples);

		if(concept_moore_machine.output_mapping[0] == type::error_type()) {
			std::cout << "Init is wrong" << std::endl;
			exit(1);
		}

		if(concept_moore_machine.initial_states.size() == 0) {
			std::cout << "No initial states of concept moore machine!" << std::endl;
			exit(1);
		}
	
	}



	/*
	 * This method shall return true if the Moore machine is equivalent to the
         * target language and false otherwise. If false is returned, then a
         * counter-example has to be provided. This counter-example is stored as the
         * <tt>ce</tt> parameter 
	 * @param conjecture The conjecture to check for equivalence
         * @param ce If the conjecture is not equivalent to the target language,
         *           this parameter is used to pass a counter-example back to the
         *           learning algorithm.
         *
         * @return Returns true if the conjecture is equivalent to the target
         *         language and false otherwise.
	 *
	 */
	bool equivalence_query(const libalf::moore_machine<type> & conjecture, std::list<int> & ce) const {
	
		// Collect the number of equivalence queries
		num_eq_queries++;
		

		std::set<unsigned int> blank_alphabet;
		assert(alphabet_to_int.count(blank_alphabet) > 0);

		// Strip error states from the conjecture
		libalf::moore_machine<type> stripped_conjecture = remove_unreachable_states(strip_error_states(conjecture, type::error_type()));

		// Is conjecture equivalent	
		if(!differently_classified_word(concept_moore_machine, stripped_conjecture, ce)) {

			return true;	
		}

		/* A differently classified word (valid counter-example) exists. */
		std::cerr << "Counter-example found: ";
		pretty_print(ce);
		//std::cerr << "target automaton: " << concept_moore_machine.visualize() << std::endl;
		//std::cerr << "conjecture automaton: " << stripped_conjecture.visualize() << std::endl;
		return false;

	}


	/*
	 * Checks whether the input word is consistemt or not. An input word is inconsistent
	 * if it contains more than one occurence of a variable (except the blank symbol) in 
	 * its sequence of alphabets.
	 */   
        bool isConsistent(std::list<int>& word) const {
	
		std::set<unsigned int> occured_variables;
		std::list<int>::iterator it;
		for(it = word.begin(); it != word.end(); it++) {
	
			assert(int_to_alphabet.count(*it) > 0);
			std::set<unsigned int> vars = int_to_alphabet.find(*it)->second;
                       	for(std::set<unsigned int>::iterator set_it = vars.begin(); set_it != vars.end(); set_it++) {
                        	if(occured_variables.count(*set_it) > 0) {
                                       	return false;
                               	} else {
                                       	occured_variables.insert(*set_it);
                               	}
			}

		}
		return true;
	}     

	void pretty_print(std::set<unsigned int> & letter) const {

		std::cerr << "{";
		for(std::set<unsigned int>::const_iterator it = letter.begin(); it != letter.end(); it++) {
			std::cerr << *it << " ";
		}
		std::cerr << "}";
	}
		
	void pretty_print(std::list<int>& word) const {
		std::list<int>::iterator it;
		for (it = word.begin(); it != word.end(); it++) {
			//std::cerr << *it << " ";
			pretty_print(int_to_alphabet[*it]);
		}
		std::cerr << std::endl;
		#if 0
		for (it = word.begin(); it != word.end(); it++) {
			std::cerr << *it << " ";
		}
		std::cerr << std::endl;
		#endif
	}

	/*
	 * Completely defines a language by providing a type for every input word.
	 */
	type membership_query(std::list<int> & word) const {

		// Collect the number of membership queries
		num_mem_queries++;

		/* quick check if the word does not satisfy strand property i.e. the word
		 * should not have more than one occurences of any non-blank symbol.
		 */
		if(!isConsistent(word)) {
			return type::error_type();
		}

		// traverse concept_moore_machine to return output type of <tt>word</tt>.
		std::set<int> cur_states = concept_moore_machine.initial_states;
		for (std::list<int>::iterator word_it = word.begin(); word_it != word.end(); word_it++) {
			if(cur_states.size() > 1) {
				std::cerr << "Nondeterminism detected!" << std::endl;
				exit(1);
			}

			int state = *(cur_states.begin());
			// Find whether the transitions has state present in its mapping ?

			if(concept_moore_machine.transitions.count(state) == 0) {
				/* No transition exists from the given state. Return default type. */
				return type::error_type();
			}

			if(concept_moore_machine.transitions.find(state)->second.count(*word_it) > 0) {
				cur_states = concept_moore_machine.transitions.find(state)->second.find(*word_it)->second;
			}
			else { /* The transition does not exist on the given word. Return default - type. */
				return type::error_type();
			}

		}

		//std::cout << "Type: " << concept_moore_machine.output_mapping.find(*(cur_states.begin()))->second.to_string() << std::endl;
		return concept_moore_machine.output_mapping.find(*(cur_states.begin()))->second;
	
	}
};




bool __get_typed_paths(const libalf::moore_machine<type> & machine, int current_state, std::list<int> var_sequence, std::list<std::pair<std::list<int>, type> > & typed_paths, int blank_symbol) {

	//std::cerr << std::endl << "====================" << std::endl << "Current state is " << current_state << std::endl;

	// Check whether there is a blank self loop in the current state
	bool has_blank_loop = false;
	std::map<int, std::map<int, std::set<int> > >::const_iterator it1 = machine.transitions.find(current_state);
	if(it1 != machine.transitions.end() && it1->second.count(blank_symbol) > 0) {
	
		std::map<int, std::set<int> >::const_iterator it2=it1->second.find(blank_symbol);
		if(it2->second.size() > 1) {
			return false;
		} else if(it2->second.size() == 1 && *(it2->second.begin()) != current_state) {
			return false;
		} else if(it2->second.size() == 1) {
			has_blank_loop = true;
		}

	}
	
	// If there is a self loop on a blank, add it to the occuring variables
	if(has_blank_loop) {
		var_sequence.push_back(blank_symbol);
	}
	
	
	// Check whether current state is a terminal state
	bool is_terminal = true;
	if(it1 != machine.transitions.end()) {
		
		unsigned int outgoing_transitions = 0;
		for(std::map<int, std::set<int> >::const_iterator it2=it1->second.begin(); it2!=it1->second.end(); it2++) {
		
			// If blank symbol, then only self-loops
			if(it2->first != blank_symbol) {
				outgoing_transitions += it2->second.size();
			}
		}
		
		if(outgoing_transitions > 0) {
			is_terminal = false;
		}
		
	}
	
	
	// Current state is a terminal state
	if(is_terminal) {
		
		assert(machine.output_mapping.count(current_state) == 1);
		
		typed_paths.push_back(std::pair<std::list<int>, type>(var_sequence, machine.output_mapping.find(current_state)->second));
		return true;
	}
	
	
	// If current state is not final, traverse the transitions and accumulate the occurring variables
	for(std::map<int, std::set<int> >::const_iterator it2=it1->second.begin(); it2!=it1->second.end(); it2++) {

		// If blank symbol, then only self-loops
		if(it2->first != blank_symbol) {
		
			for(std::set<int>::const_iterator it3=it2->second.begin(); it3!=it2->second.end(); it3++) {
			
				// Copy occurring variables
				std::list<int> new_var_sequence(var_sequence);
			
				// Accumulate the variables on this transition
				new_var_sequence.push_back(it2->first);
				
				// Traverse
				if(!__get_typed_paths(machine, *it3, new_var_sequence, typed_paths, blank_symbol)) {
					return false;
				}
			
			}
		
		}
	
	}
	
	return true;
}


/**
 * Assumes that the machine
 * - has no false, i.e., error state
 * - is well typed
 * - is elastified
 * 
 */
std::list<std::pair<std::list<int>, type> > get_typed_paths(const libalf::moore_machine<type> & machine, int blank_symbol) {

	std::list<std::pair<std::list<int>, type> > typed_paths;

	for(std::set<int>::const_iterator it=machine.initial_states.begin(); it!=machine.initial_states.end(); it++) {
		std::list<int> empty_list;
		__get_typed_paths(machine, *it, empty_list, typed_paths, blank_symbol);
		//__get_typed_paths(machine, *it, std::list<int>(), typed_paths, blank_symbol);
	}


	return typed_paths;
}

std::string print_typed_path(const std::pair<std::list<int>, type> & path) {

	std::stringstream out;
	
	// Output path
	out << "[";
	unsigned int i=0;
	for(std::list<int>::const_iterator it=path.first.begin(); it!=path.first.end(); it++) {

		// Decode the label
		assert(int_to_alphabet.count(*it) > 0);
		std::set<unsigned int> vars = int_to_alphabet.find(*it)->second;

        // Print the variables occuring together in the label
		out << "{";
		unsigned int j=0;
		for(std::set<unsigned int>::iterator set_it = vars.begin(); set_it != vars.end(); set_it++) {
			out << int_to_variables[*set_it] << (j<vars.size()-1 ? ", ": "");
			
			j++;
		}                       
        out << "}" << (i<path.first.size()-1 ? ", " : "");
		
		i++;
	
	}
	out << "]";
	
	// Output type
	out << " -> " << path.second;
	
	return out.str();

}

/**
 * Works only with a single array. Does not work for lists !!
 *
 * WARNING: VERY crappy hack!
 */
std::list<std::string> derive_constraints_from_path(const std::list<int> path) {

	/*
	 * First, get some constants
	 */
	// (libalf) Symbol representing the blank
	assert(alphabet_to_int.count(std::set<unsigned int>()) > 0);
	int blank = (int)alphabet_to_int.find(std::set<unsigned int>())->second;
	
	// Number of variable "nil"
	int nil;
	if(variables_to_int.count("nil") > 0) {
		assert(variables_to_int.count("nil") == 1);
		nil = variables_to_int.find("nil")->second;

	} else {
		nil = -1;

	}

	// Number of variable "nil_geq_size"
	int nil_geq_size;
	if(variables_to_int.count("nil_geq_size") > 0) {
		assert(variables_to_int.count("nil_geq_size") == 1);
		nil_geq_size = variables_to_int.find("nil_geq_size")->second;

	} else {
		nil_geq_size = -1;

	}


	// Number of variable "nil_le_zero"
	int nil_le_zero;
	if(variables_to_int.count("nil_le_zero") > 0) {
		assert(variables_to_int.count("nil_le_zero") == 1);
		nil_le_zero = variables_to_int.find("nil_le_zero")->second;

	} else {
		nil_le_zero = -1;

	}


	// Number of variable (predicat) "y1"
	unsigned int y1;
	if(variables_to_int.count("y1") > 0) {
		assert(variables_to_int.count("y1") == 1);
		y1 = variables_to_int.find("y1")->second;

	} else {
		y1 = -1;

	}


	// Number of variable (predicat) "size"
	unsigned int y2;
	if(variables_to_int.count("y2") > 0) {
		assert(variables_to_int.count("y2") == 1);
		y2 = variables_to_int.find("y2")->second;

	} else {
		y2 = -1;

	}


	std::list<std::string> constraints;
	
	/*
	 * Generate constraints
	 */
	unsigned int pos = 0;
	for(std::list<int>::const_iterator it=path.begin(); it!=path.end(); it++) {
	
		// Get variables encoded by the current symbol
		assert(int_to_alphabet.count(*it) == 1);
		std::set<unsigned int> vars = int_to_alphabet.find(*it)->second;
	
		/*
		 * 1. Case in paper
		 */
		// Subcase (a)
		if(vars.count(nil) == 1) {
	
			// nil_geq_size and nil_le_zero do not exist as variables in this example
			assert(nil_geq_size == -1);
			assert(nil_le_zero == -1);
	
			// Add v=nil for all variables opccuring together with nil (also y, but that should never occur)
			for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
				if(*it1 != (unsigned int)nil) {
					assert(int_to_variables.count(*it1) == 1);
					constraints.push_back("(= " + int_to_variables.find(*it1)->second + " nil)");
				}
			}
			
		} else if (vars.count(nil_geq_size) == 1) {

			// nil does not exist as a variable in this example
			assert(nil == -1);

			// Add v >= size for all variables opccuring together with nil (also y, but that should never occur)
			for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
				if(*it1 != (unsigned int)nil_geq_size) {
					assert(int_to_variables.count(*it1) == 1);
					constraints.push_back("(>= " + int_to_variables.find(*it1)->second + " size)");
				}
			}

		} else if (vars.count(nil_le_zero) == 1) {

			// nil does not exist as a variable in this example
			assert(nil == -1);

			// Add v < 0 for all variables opccuring together with nil (also y, but that should never occur)
			for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
				if(*it1 != (unsigned int)nil_le_zero) {
					assert(int_to_variables.count(*it1) == 1);
					constraints.push_back("(< " + int_to_variables.find(*it1)->second + " 0)");
				}
			}
		}
		// Subcase (b)
		else {
			for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
				std::set<unsigned int>::const_iterator tmp_it = it1;
				for(std::set<unsigned int>::const_iterator it2=++tmp_it; it2!=vars.end(); it2++) {
					assert(int_to_variables.count(*it1) == 1);
					assert(int_to_variables.count(*it2) == 1);
					constraints.push_back("(= " + int_to_variables.find(*it1)->second + " " + int_to_variables.find(*it2)->second + ")");
				}
			}
		}
	
		/*
		 * 2. Case in paper
		 * Only occurs if the data structure is an array.
		 * HACK: Requires knowledge that nil_geq_size is the variable which occurs just before the start of the array.
		 */
		if(vars.count(nil_geq_size) == 1 && pos < path.size()-1) {
			std::list<int>::const_iterator tmp_it = it;
			tmp_it++;

			// Subcase (a)			
			if(*tmp_it == blank) {
		
				if(pos < path.size()-2) {

					// Get variables encoded by the symbol 2 after the current
					tmp_it++;
					assert(int_to_alphabet.count(*tmp_it) == 1);
					std::set<unsigned int> vars_next_next = int_to_alphabet.find(*tmp_it)->second;
					
					// Add constraint
					for(std::set<unsigned int>::const_iterator it1=vars_next_next.begin(); it1!=vars_next_next.end(); it1++) {
						assert(int_to_variables.count(*it1) == 1);
						constraints.push_back("(<= 0 " + int_to_variables.find(*it1)->second + ")");
					}
				}
		
			}
			
			// Subcase (b)
			else {
			
				// Get variables encoded by the symbol 1 after the current
				assert(int_to_alphabet.count(*tmp_it) == 1);
				std::set<unsigned int> vars_next = int_to_alphabet.find(*tmp_it)->second;
					
				// Add constraint
				for(std::set<unsigned int>::const_iterator it1=vars_next.begin(); it1!=vars_next.end(); it1++) {
					assert(int_to_variables.count(*it1) == 1);
					constraints.push_back("(= 0 " + int_to_variables.find(*it1)->second + ")");
				}
			
			}
			
		}

		/* Handled all the cases to consider when nil/nil_geq_size/nil_le_zero occur along a transition.
		 * From now on, just filter this case when generating constraints.
		*/

		/*
		 * 3. Case in paper
		 */
		// Check for the second last alphabet and the last alphabet being blank.
		if(pos == path.size()-2) {
	
			// Only generated if nil variables do not occur in the transition.
			// If nil variables do occur along the transition, handled in Case 2 above.
			if (vars.count(nil) == 0 && vars.count(nil_geq_size) == 0 && vars.count(nil_le_zero) == 0) {
	
				std::list<int>::const_iterator tmp_it = it;
				tmp_it++;
				// Subcase (a)
				if(*tmp_it == blank) {

					// Add constraint
					for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
						assert(int_to_variables.count(*it1) == 1);
						constraints.push_back("(< " + int_to_variables.find(*it1)->second + " size)");
					}
				
				}
			}

		} 
		// 2nd part
		// Check for the last element if it is not blank
		else if (pos == path.size() - 1) {

			// Only generated if nil variables do not occur in the transition.
			// If nil variables do occur along the transition, handled in Case 2 above.
			if (vars.count(nil) == 0 && vars.count(nil_geq_size) == 0 && vars.count(nil_le_zero) == 0) {
				std::list<int>::const_iterator tmp_it = it;
				if (*tmp_it != blank) {
				
					// Add constraint
					for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
						assert(int_to_variables.count(*it1) == 1);
						constraints.push_back("(= " + int_to_variables.find(*it1)->second + " (- size 1))");
					}
				
				}
			}
				
		}
		
		/*
		 * 4. Case in paper
		 */
		if(pos < path.size()-1) {

			std::list<int>::const_iterator tmp_it = it;
			tmp_it++;

			// alphabet next to the current is blank
			if(*tmp_it == blank && pos < path.size() - 2) {

				// Get variables encoded by the symbol next to next to the current
				tmp_it++;
				assert(int_to_alphabet.count(*tmp_it) == 1);
				std::set<unsigned int> vars_next_next = int_to_alphabet.find(*tmp_it)->second;

				// vars contains exactly the variable "y1" --> vars.size() == 1
				// vars_next_next contains exactly the variable y2 --> vars_next_next.size() = 1
				// Note this case does not interfere with nil variables. So this check is not required here.
				if (vars.count(y1) == 1 && vars.size() == 1 && vars_next_next.count(y2) == 1 && vars_next_next.size() == 1) {

					for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
						for(std::set<unsigned int>::const_iterator it2=vars_next_next.begin(); it2!=vars_next_next.end(); it2++) {
							assert(int_to_variables.count(*it1) == 1);
							assert(int_to_variables.count(*it2) == 1);
							constraints.push_back("(<= " + int_to_variables.find(*it1)->second + " " + int_to_variables.find(*it2)->second + ")");
						}
					}		

				}
				// Part 2. Some pointers variables exist in vars or vars_next_next 
				// The relation in this case should be < and not <=.
				else {

					// Filter out the case when nil variables occur.
					if (vars.count(nil) == 0 && vars.count(nil_geq_size) == 0 && vars.count(nil_le_zero) == 0 && vars_next_next.count(nil) == 0 && vars_next_next.count(nil_geq_size) == 0 && vars_next_next.count(nil_le_zero) == 0) {
					
						for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
							for(std::set<unsigned int>::const_iterator it2=vars_next_next.begin(); it2!=vars_next_next.end(); it2++) {
								assert(int_to_variables.count(*it1) == 1);
								assert(int_to_variables.count(*it2) == 1);
								constraints.push_back("(< " + int_to_variables.find(*it1)->second + " " + int_to_variables.find(*it2)->second + ")");
							}
						}
					}

				}

			}
		
		}
		
		/*
		 * 5. Case in paper
		 */
		if (pos < path.size() - 1) {

			std::list<int>::const_iterator tmp_it = it;
			tmp_it++;

			// alphabet next to the current is not blank
			if (*tmp_it != blank) {

				assert(int_to_alphabet.count(*tmp_it) == 1);
				std::set<unsigned int> vars_next = int_to_alphabet.find(*tmp_it)->second;
					
				// Filter out the case when nil variables occur.
				if (vars.count(nil) == 0 && vars.count(nil_geq_size) == 0 && vars.count(nil_le_zero) == 0 && vars_next.count(nil) == 0 && vars_next.count(nil_geq_size) == 0 && vars_next.count(nil_le_zero) == 0) {

					for(std::set<unsigned int>::const_iterator it1=vars.begin(); it1!=vars.end(); it1++) {
						for(std::set<unsigned int>::const_iterator it2=vars_next.begin(); it2!=vars_next.end(); it2++) {
							assert(int_to_variables.count(*it1) == 1);
							assert(int_to_variables.count(*it2) == 1);
							constraints.push_back("(= (+ " + int_to_variables.find(*it1)->second + " 1) " + int_to_variables.find(*it2)->second + ")");
						}
					}

				}

			}

		}

		
		pos++;
		
	}

	


	return constraints;

}

std::string derive_typed_path_formula(const std::pair<std::list<int>, type> & typed_path) {

	std::stringstream out;
	
	/*
	 * Output conjuction of path constraints
	 */
	out << "\t(implies " << std::endl;
	if(typed_path.first.size() == 0) {
	
		out << "\t\t(true)" << std::endl;
	
	} else {

		std::list<std::string> constraints = derive_constraints_from_path(typed_path.first);
	
		out << "\t\t(and" << std::endl;
		out << "\t\t\t";
		unsigned int i=0;
		for(std::list<std::string>::const_iterator it=constraints.begin(); it!=constraints.end(); it++) {
		
			out << *it << " ";
			
			i++;
		}
		out << std::endl << "\t\t)" << std::endl;
		
	}

	/*
	 * Output data formula derived from type
	 */
	// First, check how many formulas will be outputted
	unsigned int f_count = 0;
	for(unsigned int j=0; j<data_formulas.size(); j++) {
		if ((typed_path.second.ptr->d_type[2*j] && !typed_path.second.ptr->d_type[2*j+1]) || (!typed_path.second.ptr->d_type[2*j] && typed_path.second.ptr->d_type[2*j+1])) {
			f_count++;
		}
	}
	
	// Now output
	
	assert(typed_path.second.ptr != NULL);
	if(f_count == 0) {
	
		out << "\t\t(true)" << std::endl;
	
	} else {

		out << "\t\t(and" << std::endl;
		out << "\t\t\t";
		unsigned int i=0;
		for(unsigned int j=0; j<data_formulas.size(); j++) {

			if (typed_path.second.ptr->d_type[2*j] && typed_path.second.ptr->d_type[2*j+1]) {
				; // data_type = 11 (Top)
		
			} else if (typed_path.second.ptr->d_type[2*j] && !typed_path.second.ptr->d_type[2*j+1]) {
				out << "(" << data_formulas[j].c_str() << ") ";
				i++;
				// data_type = 10 (True)

			} else if (!typed_path.second.ptr->d_type[2*j] && typed_path.second.ptr->d_type[2*j+1]) {
				out << "(not (" << data_formulas[j].c_str() << ")) " ;
				i++;
				// data_type = 01 (False)
			
			} else if (!typed_path.second.ptr->d_type[2*j] && !typed_path.second.ptr->d_type[2*j+1]) {
				; 
				// data_type = 00 (Bot)

			} 

		}
		out << std::endl << "\t\t)" << std::endl;
		
	}
	out << "\t)" << std::endl;	
	
	return out.str();
}


std::string derive_formula(const std::list<std::pair<std::list<int>,type> > & typed_paths) {

	std::stringstream out;


	out << "(forall (";

	if(variables_to_int.count("y1") == 1)
		out << "(y1 Int) ";

	if(variables_to_int.count("y2") == 1)
		out << "(y2 Int) ";

	out << ")" << std::endl;


	out << "(and " << std::endl ;

	//std::list<std::pair<std::list<int>, type> >::const_iterator it_path;
	for(std::list<std::pair<std::list<int>,type> >::const_iterator it_path=typed_paths.begin(); it_path != typed_paths.end(); it_path++) {
		out << derive_typed_path_formula(*it_path);
		out << std::endl << std::endl;
	}


	/* 
	 * Handle the case of paths going to false
	*/
	
	out << "\t" << "(implies" << std::endl;

	if(variables_to_int.count("y2") == 1)
		out << "\t\t" << "(and (<= 0 y1) (< y1 y2) (< y2 size)" << std::endl;
	else
		out << "\t\t" << "(and (<= 0 y1) (< y1 size)" << std::endl;
	

	out << "\t\t" << "(not" << std::endl;


	out << "\t\t" << "(or" << std::endl;	

	for(std::list<std::pair<std::list<int>,type> >::const_iterator it_path=typed_paths.begin(); it_path != typed_paths.end(); it_path++) {

		std::list<std::string> constraints = derive_constraints_from_path(it_path->first);

                out << "\t\t\t(and" << std::endl;
                out << "\t\t\t\t";
                unsigned int i=0;
                for(std::list<std::string>::const_iterator it=constraints.begin(); it!=constraints.end(); it++) {

                        out << *it << " ";

                        i++;
                }
                out << std::endl << "\t\t\t)" << std::endl;
	}

	out << "\t\t)" << std::endl;

	out << "\t\t)" << std::endl;

	out << "\t\t)" << std::endl;

	out << "\t\t(false)" << std::endl;

	out << "\t)";

	out << std::endl << ")" << std::endl << ")" << std::endl;


	return out.str();

}



int main(int argc, char* argv[]) {
	
	clock_t start_t1, end_t1, start_t2, end_t2;

	start_t1 = clock();

	if(argc != 2) {
		std::cout << "Incorrect arguments to the program\n";
		exit(-1);
	}
	else {
		fileName = argv[1];		
	}

	test_teacher t(0);

	end_t1 = clock();
	start_t2 = clock();


	libalf::moore_machine<type> * result = learn(t, t.alphabet_size);


	assert(alphabet_to_int.count(std::set<unsigned int>()) > 0);
	unsigned int blank_symbol = alphabet_to_int.find(std::set<unsigned int>())->second;

	libalf::moore_machine<type> stripped_conjecture = remove_unreachable_states(strip_error_states(*result, type::error_type()));
        // Print the QDA learnt
	//std::cout << print(stripped_conjecture, data_formulas) << std::endl;

	// Elastify the QDA to get the corresponding EQDA
        libalf::moore_machine<type> strandified_conjecture = strandify(stripped_conjecture, simple_test_join(), blank_symbol);
        strandified_conjecture = remove_unreachable_states(strip_error_states(strandified_conjecture, type::error_type()));
        
	// Print the EQDA
        std::cout << print(strandified_conjecture, data_formulas) << std::endl;


	std::cerr << "Number of Membership Queries: " << num_mem_queries << std::endl;
	std::cerr << "Number of Equivalence Queries: " << num_eq_queries << std::endl;
	std::cerr << "Size of learnt QDA: " << stripped_conjecture.state_count << std::endl;	
	std::cerr << "Size of learnt EQDA: " << strandified_conjecture.state_count << std::endl;	

	#ifdef GENERATE_APF_FORMULAS
	// Get the blank symbol
	assert(alphabet_to_int.count(std::set<unsigned int>()) > 0);
	
	//std::list<std::pair<std::list<int>, type> > typed_paths = get_typed_paths(strandified_conjecture, alphabet_to_int.find(std::set<unsigned int>())->second);
	std::list<std::pair<std::list<int>, type> > typed_paths = get_typed_paths(strandified_conjecture, blank_symbol);

	std::cerr << derive_formula(typed_paths) << std::endl;
	#endif
	
	end_t2 = clock();
	fprintf(stderr, "Time to build teacher: %fn sec\n", (double)(end_t1 - start_t1) / CLOCKS_PER_SEC);
	fprintf(stderr, "Time to learn: %fn sec\n", (double)(end_t2 - start_t2) / CLOCKS_PER_SEC);
	
	delete result;

}
