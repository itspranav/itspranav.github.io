#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <utility>


std::string input_filename = "";
std::string output_filename = "";
std::ofstream outfile;
std::ifstream infile;


/* A template for all data formulas of interest. */
struct data_formula_struct {
	std::string operand1;
	std::string operand2;
	std::string op;
};

std::map<std::string, std::string> variable_type;

/* Number of lists to be tracked in the example. Read as input from the file "list-insert.input" */
int num_lists;

/* A vector of all data-formulas over a template of the form "var1 op var2" where op = {<, <=, ==} and var1 and var2
 * are all variables in the example (provided by the user).
 * The data formulas are evaluated over the lattice {bot, false, true, top}. */
std::vector<data_formula_struct> data_formulas;

/* A double dimension vector of strings which stores all the variables in the example. The x-dimension of the
 * 2D vector = <tt>num_lists</tt> + 3. The variables are stored in an hierarchichal manner where all the variables 
 * pointing into the same list are inserted into the same vector: variables[i]. In particular:
 * variables[0] = {nil}
 * variables[1] = {x | x is a pointer into list1} U {star1}
 * variables[2] = {x | x is a pointer into list2} U {star2}
 * ...
 * variables[num_lists+1] = {y1, y2}
 * variables[num_lists+2] = {x | x is an integer variable in the example} */
std::vector<std::vector<std::string> > variables;


void print_data_type(std::vector<bool> &data_type) {

	unsigned int i;
	for(i = 0; i < data_type.size(); i++) {
		if(data_type[i]) outfile << "1";
		else outfile << "0";
	}

}

/* TODO: Pass all the variables in the example as formal parameters to this method. */
void generate_valuation_words(int A[], int index, int size, int key) {

	for (int i = 1; i <= num_lists; i++) {
		int y1;
		/*
		 * TODO: In case of multiple lists, initialize y1 with the pointer to the respective list.
		 * For eg. the if-conditional when num_lists = 2:
		 * 	if (i == 1) y1 = head1; 
		 *	else if (i == 2) y1 = head2;
		 *	else ...
		 */
		if(i == 1) y1 = 0;
		else {
			std::cout << "Number of lists in the example = " << num_lists << std::endl;
			std::cout << "Number of lists does not tally with the instrumentation code." << std::endl;
			exit(1);
		}

		while (y1 < size) {

					std::vector<bool> data_type;
					std::vector<data_formula_struct>::iterator it;
					for(it = data_formulas.begin(); it < data_formulas.end(); it++) {

						int val1 = 0; int val2 = 0;
						bool is_bot = false;
						bool result = false;

						/* TODO: Manually match <tt>*it.operand1</tt> with each variable and 
						 * store the corresponding data value in <tt>val1</tt> */
						if((*it).operand1.compare("(A index)") == 0) {
		
							if (index < size)	val1 = A[index];
							else is_bot = true;

						} else if ((*it).operand1.compare("(A y1)") == 0) {
			
							if (y1 < size)  val1 = A[y1];
							else is_bot = true;

						} else if ((*it).operand1.compare("(A size)") == 0) {

							if (size < size)  val1 = A[size];
							else is_bot = true;

						} else if ((*it).operand1.compare("key") == 0) {

							val1 = key;
						}	


						/* TODO: Manually match <tt>*it.operand2</tt> with each variable and 
						 * store the corresponding data value in <tt>val2</tt> */
						if((*it).operand2.compare("(A index)") == 0) {
			
							if (index < size)	val2 = A[index];
							else is_bot = true;

						} else if ((*it).operand2.compare("(A y1)") == 0) {
			
							if (y1 < size)  val2 = A[y1];
							else is_bot = true;

						} else if ((*it).operand2.compare("(A size)") == 0) {

							if (size < size)  val2 = A[size];
							else is_bot = true;

						} else if ((*it).operand2.compare("key") == 0) {

							val2 = key;
						}	


						if((*it).op.compare("<") == 0) {

							result = (val1 < val2);

						} else if ((*it).op.compare("<=") == 0) {
		
							result = (val1 <= val2);
							
						} else if ((*it).op.compare("=") == 0) {
		
							result = (val1 == val2);

						}

						/* Use the result to generate the data_type.
						 * Encode: is_bot = true --> 00
						 *   	   else result = true --> 10
						 *	   else result = false --> 01
						 */
						if(is_bot) {

							data_type.push_back(false);
							data_type.push_back(false);

						} else if (result) {

							data_type.push_back(true);
							data_type.push_back(false);

						} else {

							data_type.push_back(false);
							data_type.push_back(true);

						}


					}

					// Store the valuation word in the data-base with its corresponding data_type.
					int node;
                                        outfile << "string:";


					/* TODO: Compare all the pointer variable in the program to node (NULL). */
                                        outfile << "{nil_le_zero ";
                                        if (index < 0) outfile << "index ";
                                        if (y1 < 0) outfile << "y1 ";
                                        if (size < 0) outfile << "size ";
                                        outfile << "}";

                                        outfile << "{nil_geq_size ";
                                        if (index >= size) outfile << "index ";
                                        if (y1 >= size) outfile << "y1 ";
                                        if (size >= size) outfile << "size ";
                                        outfile << "}";
					
					
					for (int k = 1; k <= num_lists; k++) {

				 		/* TODO: In case of multiple lists, initialize node with the pointer to the respective list. */
						if (k == 1) node = 0;
						else {
							std::cout << "Number of lists does not tally with variable \"num_lists\"" << std::endl;
						}

						while (node < size) {

							/* TODO: Compare all the pointer variable in the program to node. */
                                                	outfile << "{";
							if (index == node) outfile << "index "; 
							if (y1 == node) outfile << "y1 "; 
							if (size == node) outfile << "size "; 
							outfile << "}";

							node++;
						}

						/* TODO */
						if (k == 1 && k < num_lists) outfile << "{star1 }";
						/*else if (k == 2) outfile << "{star2 }";*/
					}

                                        outfile << ":";
                                        print_data_type(data_type);
                                        outfile << std::endl;
					
			
			y1++;
		}
	}

	return;
}


void instrumentation_init() {

	std::string line;
	while (!infile.eof())	 {

		getline(infile, line);

		if(line.size() == 0)
			continue;
		
		if(line.compare(0, 10, "num_lists:") == 0) {
			line.replace(0, 10, "");
			std::stringstream convert(line);
			convert >> num_lists;
			/* one index for each list (1, 2, 3 ... onwards) + index zero for variable "nil" + 
			 * last index (num_lists + 3) for integer variables + last but one index (num_lists + 2) 
			 * for universal variables.
			 */
			variables.resize(num_lists + 3);

			continue;

		} else if (line.compare(0, 4, "list") == 0) {

			line.replace(0, 4, "");
			size_t pos = line.find(":", 0);
			if (pos != std::string::npos) {

				int list_index;
				std::stringstream convert(line.substr(0, pos+1));
				convert >> list_index;
				line.replace(0, pos+1, "");

				variables[list_index].push_back(line);
				variable_type.insert(make_pair(line, "pointer"));
				continue;

			} else {

				std::cout << "Invalid input file format" << std::endl;
				exit(1);
			}

		} else if (line.compare(0, 8, "integer:") == 0) {

			line.replace(0, 8, "");

			variables[num_lists+2].push_back(line);
			variable_type.insert(make_pair(line, "integer"));
			continue;

		} else if (line.compare(0, 10, "universal:") == 0) {

			line.replace(0, 10, "");

			variables[num_lists+1].push_back(line);
			variable_type.insert(make_pair(line, "universal"));
			continue;

		} else {

			std::cout << "Invalid input file format" << std::endl;
			exit(1);

		}

	}

	std::vector<std::string> flat_vars;
	/*for (std::vector<std::vector<std::string> >::iterator it1 = variables.begin(); it1 < variables.end(); it1++) {
		for (std::vector<std::string>::iterator it2 = it1->begin(); it2 < it1->end(); it2++) {

			flat_vars.push_back(*it2);
		}
	}*/
	for (unsigned int i = num_lists + 1; i <= num_lists + 2; i++) {
                for (std::vector<std::string>::iterator it2 = variables[i].begin(); it2 < variables[i].end(); it2++) {

                        flat_vars.push_back(*it2);
                }
        }

	for (std::vector<std::string>::iterator it1 = flat_vars.begin(); it1 < flat_vars.end(); it1++) {
		for (std::vector<std::string>::iterator it2 = it1 + 1; it2 < flat_vars.end(); it2++) {

			data_formula_struct f;

			if(variable_type.find(*it1)->second.compare("integer") == 0)
				f.operand1 = *it1;
			else {
				std::string temp = "(A ";
				temp += *it1;
				temp += ")";
				f.operand1 = temp;
			}


			if(variable_type.find(*it2)->second.compare("integer") == 0)
				f.operand2 = *it2;
			else {
				std::string temp = "(A ";
				temp += *it2;
				temp += ")";
				f.operand2 = temp;
			}
	
			f.op = "<";
			data_formulas.push_back(f);
			
			f.op = "<=";
			data_formulas.push_back(f);

			f.op = "=";
			data_formulas.push_back(f);
		}
	}

	variables[0].push_back("nil_geq_size");
        variables[0].push_back("nil_le_zero");
	int count = 1;
	for (std::vector<std::vector<std::string> >::iterator it = variables.begin() + 1; it < variables.end() - 3; it++) {
		std::stringstream convert;
		convert << count;
		std::string str = "star";
		str += convert.str();
		it->push_back(str);
		count++;
	}

	
	for (std::vector<data_formula_struct>::iterator it = data_formulas.begin(); it < data_formulas.end(); it++) {
		outfile << "data_formula:" << it->op.c_str() << " " << it->operand1.c_str() << " " << it->operand2.c_str() << "." << std::endl;
	}

	count = 0;
	for (std::vector<std::vector<std::string> >::iterator it1 = variables.begin(); it1 < variables.end() - 1; it1++) {
		for (std::vector<std::string>::iterator it2 = it1->begin(); it2 < it1->end(); it2++) {

			outfile << "variable:" << it2->c_str() << ":" << count << "." << std::endl;
			count++;
		}
	}

}


int array_find(int A[], int size, int key) {


	// Print the list and the key for debugging purposes.
	int index = 0;

	/* Instrumentation code */
	generate_valuation_words(A, index, size, key);	
	/* Instrumentation code */

	while (index < size) {

		if(A[index] == key)
			return index;

		index++;
		
		/* Instrumentation code */
		generate_valuation_words(A, index, size, key);	
		/* Instrumentation code */
	}

	return size;
	
}
/* post: sorted_list(head) /\ head != NULL */

int main(int argc, char* argv[]) {

	if(argc != 3) {
                std::cout << "Incorrect arguments to the program\n";
                exit(-1);
        }
        else {
                input_filename = argv[1];
                output_filename = argv[2];
        }

	infile.open(input_filename.c_str(), std::ios::in);
	outfile.open(output_filename.c_str(), std::ios::out);

	instrumentation_init();

	srand(time(NULL));



	/* Generate array samples populated with data values 0 and 2 !!
	 * len: iterator for generating lists of all lengths from 1 to 5.
	 */

	int len, iter;

	std::set< std::vector<int> > list_contents;
	std::vector<int> temp_vector;
	temp_vector.push_back(0);  
	list_contents.insert(temp_vector);

	temp_vector.clear();
	temp_vector.push_back(2);  
	list_contents.insert(temp_vector);

	int count = 0;
	for(len = 1; len <= 5; len++) {
		
		for(std::set< std::vector<int> >::iterator it = list_contents.begin(); it != list_contents.end(); it++) {
			std::vector<int> contents = *it;

			int num_to_find;
			for(num_to_find = -1; num_to_find <= 3; num_to_find++) {

				int A[5];

				for(iter = 0; iter < len; iter++) {
					A[iter] = contents[iter];
				}
				count++;
				array_find(A, len, num_to_find);
			}
		}	

		std::set< std::vector<int> > temp_set;
		for(std::set< std::vector<int> >::iterator it = list_contents.begin(); it != list_contents.end(); it++) {
			temp_vector = *it;
			temp_vector.push_back(0);
			temp_set.insert(temp_vector);

			temp_vector = *it;
			temp_vector.push_back(2);
			temp_set.insert(temp_vector);
		}
		list_contents = temp_set;
	}
	std::cout << "count: " << count << std::endl;

	outfile.close();
	infile.close();
	return 0;
}
