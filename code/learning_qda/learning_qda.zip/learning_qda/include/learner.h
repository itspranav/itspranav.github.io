#ifndef __LEARNER_H__
#define __LEARNER_H__

#include <list>

#include "libalf/conjecture.h"
#include "libalf/knowledgebase.h"
#include "libalf/algorithm_angluin.h"
#include "libalf/algorithm_rivest_schapire.h"

libalf::moore_machine<type> * learn(teacher & t, unsigned int alphabet_size) {

	libalf::knowledgebase<type> base;
	//libalf::angluin_simple_table<type> alg(&base, NULL, alphabet_size);
	libalf::rivest_schapire_table<type> alg(&base, NULL, alphabet_size);
	
	
	libalf::moore_machine<type> * result = NULL;
	while(!result) {

		// Advance learning algorithm
		libalf::conjecture * conjecture = alg.advance();
		
		// Equivalence query
		if(conjecture) {
		
			// Cast to moore_machine
			libalf::moore_machine<type> * cast_conjecture = dynamic_cast<libalf::moore_machine<type> *>(conjecture);
			if(!cast_conjecture) {
				std::cerr << "Something went terribly wrong!" << std::endl;
				exit(1);
			}
		
			// Check equivalence
			std::list<int> ce;
			if(t.equivalence_query(*cast_conjecture, ce)) {
				result = cast_conjecture;
			} else {
				
				// Add counter-example
				alg.add_counterexample(ce);
				
				// Delete conjecture
				delete cast_conjecture;
			}
		
		}
		
		// Membership queries
		else {
		
			std::list<std::list<int> > queries = base.get_queries();
			for(std::list<std::list<int> >::iterator it=queries.begin(); it!=queries.end(); it++) {
			
				type a = t.membership_query(*it);
				base.add_knowledge(*it, a);
				
			}
		
		}
	
	}

	return result;
}

#endif
