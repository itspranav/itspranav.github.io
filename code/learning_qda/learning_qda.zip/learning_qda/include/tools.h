#ifndef __TOOLS_H__
#define __TOOLS_H__

#include <iostream>
#include <map>
#include <list>

#include <cstring>

#include "types.h"
#include "libalf/conjecture.h"


/**
 * << operator for libalf words.
 *
 * @param out The output stream to write to
 * @param t The wortd to write
 *
 * @return Returns the output stream given by <tt>out</tt>.
 */
std::ostream & operator<<(std::ostream & out, std::list<int> const & w) {

	out << "[";

	unsigned int i=0;
	for(std::list<int>::const_iterator it=w.begin(); it!=w.end(); it++) {
		out << *it << (i<w.size()-1 ? " " : "");
		i++;
	}

	out << "]";
	
	return out;
}

/**
 * Searches for a word that has a different output when given as input to the
 * Moore machines <tt>m1</tt> and <tT>m2</tt>. Booth Moore machines have to be
 * deterministic, but they do not need to be complete (i.e., not every
 * transition needs to be defined. The function checks only those words that are
 * properly processed by both Moore machines (meaning that a run of both
 * machines exists on such a word).
 *
 * This function returns false, if all words properly processed by both Moore
 * machines have the same output. If the Moore machines disagree on a word, the
 * function returns true. In the latter case, such a word is stored in the
 * <tt>word</tt> parameter.
 *
 * This function computes the product of <tt>m1</tt> and <tt>m2</tt> on-the-fly
 * and checks whether the pairs of states reached have the same output. This is
 * done using recursive calls to the function. The current state in the product
 * is stored in the two parameters <tt>q1</tt> and <tt>q2</tt> (<tt>q1</tt> is a
 * state of <tt>m1</tt> and <tt>q2</tt> of <tt>m2</tt>).
 *
 * <tt>visited</tt> is a two-dimensional array of size
 * <tt>m1.node_count * m2.node_count</tt> that stores whether a state in the
 * product has already been visited.
 *
 * If a word with different outputs is found, a word leading to this state
 * is constructed by traversing the transition backwards. However, this is done
 * implicitely utilizing the order of the recurisive function calls.
 *
 * @param m1 The first Moore machine
 * @param m2 The second Moore machine
 * @param word If a differently classified word is found, it is stored in this
 *             parameter
 * @param q1 The current state of <tt>m1</tt> in the product
 * @param q2 The current state of <tt>m2</tt> in the product
 * @param visited A bool array big enough to store whether a state in the
 *                product automaton has already been visited
 *
 * @return Returns true if a differently classified word exists and otherwise
 *                 false.
 */
template <class answer>
bool __differently_classified_word(const libalf::moore_machine<answer> & m1, const libalf::moore_machine<answer> & m2, std::list<int> & word, int q1, int q2, bool ** visited) {

	// Skip state if it has already been visited
	if(visited[q1][q2]) {
		return false;
	}
	// Otherwise, mark it as visited
	else {
		visited[q1][q2] = true;
	}

	// Compare output of state pair
	typename std::map<int, answer>::const_iterator out1 = m1.output_mapping.find(q1);
	typename std::map<int, answer>::const_iterator out2 = m2.output_mapping.find(q2);
	if((out1 != m1.output_mapping.end() && out2 == m2.output_mapping.end()) || (out1 == m1.output_mapping.end() && out2 != m2.output_mapping.end()) || (out1->second != out2->second)) {
		return true;
	}
	
	// Traverse the transitions
	std::map<int, std::map<int, std::set<int> > >::const_iterator it1 = m1.transitions.find(q1);
	std::map<int, std::map<int, std::set<int> > >::const_iterator it2 = m2.transitions.find(q2);
	if(it1 != m1.transitions.end() && it2 != m2.transitions.end()) {
	
		for(std::map<int, std::set<int> >::const_iterator it3=it1->second.begin(); it3!=it1->second.end(); it3++) {
		
			std::map<int, std::set<int> >::const_iterator it4 = it2->second.find(it3->first);
			if(it4 != it2->second.end()) {
		
				for(std::set<int>::const_iterator it5=it3->second.begin(); it5!=it3->second.end(); it5++) {
					for(std::set<int>::const_iterator it6=it4->second.begin(); it6!=it4->second.end(); it6++) {
						
						// Do recursive call
						if(__differently_classified_word(m1, m2, word, *it5, *it6, visited)) {

							// Construct word leading to states with different output in a backwards manner
							word.push_front(it3->first);
						
							return true;
				
						}
						
					}
				}
		
			} else {
				// m2 does not have transition on alphabet it3->first while m1 has a transition.
				word.push_front(it3->first);
				return true;
				
			}
			
		}
	
	} else if (it1 != m1.transitions.end() && it2 == m2.transitions.end()) {

		// m2 does not have any transition while m1 has atleast transition.
		std::map<int, std::set<int> >::const_iterator it3 = it1->second.begin();
		word.push_front(it3->first);

		return true;

	}

	return false;
}

/**
 * Searches for a word that has a different output when given as input to the
 * Moore machines <tt>m1</tt> and <tT>m2</tt>. Booth Moore machines have to be
 * deterministic, but they do not need to be complete (i.e., not every
 * transition needs to be defined. The function checks only those words that are
 * properly processed by both Moore machines (meaning that a run of both
 * machines exists on such a word).
 *
 * This function returns false, if all words properly processed by both Moore
 * machines have the same output. If the Moore machines disagree on a word, the
 * function returns true. In the latter case, such a word is stored in the
 * <tt>word</tt> parameter. If no such word is found, then <tt>word</tt> is
 * left unchanged. Note, however, that this function does not find a particular
 * word (i.e., the word might not be the shortest etc.).
 *
 * @param m1 The first Moore machine
 * @param m2 The second Moore machine
 * @param word If a differently classified word is found, it is stored in this
 *             parameter
 *
 * @return Returns true if a differently classified word exists and otherwise
 *                 false.
 */
template <class answer>
bool differently_classified_word(const libalf::moore_machine<answer> & m1, const libalf::moore_machine<answer> & m2, std::list<int> & word) {

	// Prepare array of visited states in the product
	bool ** visited = new bool * [m1.state_count];
	for(int i=0; i<m1.state_count; i++) {
		visited[i] = new bool[m2.state_count];
		memset(visited[i], false, m2.state_count * sizeof(bool));
	}
	
	// Start search from any combination of initial states
	bool found_different_classification = false;
	for(std::set<int>::const_iterator it1=m1.initial_states.begin(); it1!=m1.initial_states.end(); it1++) {

		for(std::set<int>::const_iterator it2=m2.initial_states.begin(); it2!=m2.initial_states.end(); it2++) {
			
			std::list<int> ce;
			if(__differently_classified_word(m1, m2, ce, *it1, *it2, visited)) {
				word = ce;
				found_different_classification = true;
				break;
			}
			
		}
		
		if(found_different_classification) {
			 break;
		}
		
	}

	// Delete visited array
	for(int i=0; i<m1.state_count; i++) {
		delete[] visited[i];
	}
	delete[] visited;
	
	return found_different_classification;
}

/**
 * Computes the set of states reached from a given set of states by a
 * (possibly empty) sequence of <tt>blank_symbol</tt> symbols (the
 * <i>closure</i> of the given set). If the parameter <tt>blank_symbol</tt> i
 * not given, the default value <tt>0</tt> is used.
 *
 * @param states A (sub)set of states to compute the closure from
 * @param input A Moore machine
 * @param blank_symbol The blank symbol (defaults to <tt>0</tt>)
 *
 * @return Returns the closure of the given set.
 */
template <class answer>
std::set<int> closure(const std::set<int> & states, const libalf::moore_machine<answer> & input, int blank_symbol = 0) {

	assert(blank_symbol>=0);

	std::set<int> old_states; 
	std::set<int> new_states = states;
	
	do {
	
		old_states = new_states;
	
		#if 0
		std::cout << "Old states:";
		for(std::set<int>::iterator it=old_states.begin(); it!=old_states.end(); it++) {
			std::cout << " " << *it;
		}
		std::cout << std::endl;
		#endif
	
		for(std::set<int>::iterator it=old_states.begin(); it!=old_states.end(); it++) {
		
			std::map<int, std::map<int, std::set<int> > >::const_iterator t1_it = input.transitions.find(*it);
			if(t1_it != input.transitions.end()) {
			
				std::map<int, std::set<int> >::const_iterator t2_it = t1_it->second.find(blank_symbol);
				if(t2_it != t1_it->second.end()) {
				
					#if 0
					std::cout << "t[" << t1_it->first << "][" << t2_it->first << "] = {";
					for(std::set<int>::iterator it=t2_it->second.begin(); it!=t2_it->second.end(); it++) {
						std::cout << " " << *it;
					}
					std::cout << "}" <<std::endl;
					#endif
			
					new_states.insert(t2_it->second.begin(), t2_it->second.end());

				}
			
			}
		
		}
	
	} while(old_states.size() != new_states.size());

	return new_states;
}

/**
 * Computes the unique "smallest" overapproximation of the given language that
 * has the STRAND property.
 *
 * This method implements some kind of powerset construction to compute the
 * "smallest" overapproximation (with respect to language inclusion) that has
 * the STRAND property of language given as a Moore machine. It uses a
 * data_type_join object to compute the join of two data types. The blank
 * symbol can be any valid symbol and defaults to <tt>0</tt>.
 *
 * @param input The language to overapprocimate given as a Moore machine
 * @param join An object used to compute joins of two data types
 * @param blank_sybol The blank symbol (drfaults to <tt>0</tt>)
 *
 * @return Returns the unique "smallest" overapproximation (as a Moore machine)
 *         that has the STRAND property of the given language.
 */
libalf::moore_machine<type> strandify(const libalf::moore_machine<type> & input, const data_type_join & join, int blank_symbol = 0) {

	// Maps the states of the new automaton to their IDs
	std::map<int, std::set<int> > states;
	
	// Output of the new automaton
	std::map<int, type> output_mapping;
	
	// Transitions of the new automaton
	std::map<int, std::map<int, std::set<int> > > transitions;

	
	// Create the initial state
	std::set<int> initial;
	initial.insert(0);
	states[0] = closure(initial, input, blank_symbol);
	
	// We want to have a list containing all new states that have not yet been processed
	std::list<int> queue;
	queue.push_back(0);
	
	/*
	 * Make a breadth first traversal and create the new automaton step-by-step
	 */
	while(!queue.empty()) {
	
		// Get next state to process
		int cur_state = queue.front();
		queue.pop_front();
	
		#ifdef VERBOSE
		std::cout << "Processing state " << cur_state << ": {";
		for(auto it=states[cur_state].begin(); it!=states[cur_state].end(); it++) {
			std::cout << " " << *it;
		}
		std::cout << "}" << std::endl;
		#endif
	
		/*
		 * Create formula for the new state
		 */
		switch(states[cur_state].size()) {
			
			// This should not happen if the input is deterministic
			case 0: {
				//std::cerr << "Whoops, something went wrong! Setting output to default type!" << std::endl;
				output_mapping[cur_state] = type::error_type();
				break;
			}
		
			// If the current state is a singleton, then simply copy the type of
			// the original state
			case 1: {
				std::map<int, type>::const_iterator it = input.output_mapping.find(*(states[cur_state].begin()));
				assert(it != input.output_mapping.end());
				output_mapping[cur_state] = it->second;
				break;
			}
			
			// If there is more than one state, we need to join all types
			default: {

				// Get data type of first state
				std::set<int>::const_iterator it=states[cur_state].begin();
				std::map<int, type>::const_iterator old_type_it = input.output_mapping.find(*it);
				it++;
				
				assert(old_type_it != input.output_mapping.end());
				type t = old_type_it->second;

				// Compute join				
				for(; it!=states[cur_state].end(); it++) {
				
					// Get type of old state
					old_type_it = input.output_mapping.find(*it);
					assert(old_type_it != input.output_mapping.end());
			
					join.join(t, old_type_it->second, t);

					#if 0
					std::cout << "Join op1: " << t.to_string() << std::endl;
					std::cout << "Join op2: " << old_type_it->second.to_string() << std::endl;
					std::cout << "Result  : " << t.to_string() << std::endl;
					#endif
				}
				
				output_mapping[cur_state] = t;
				break;
			}
			
		}
		
		#ifdef VERBOSE
		std::cout << "Output type is " << output_mapping[cur_state] << std::endl;
		#endif
		
		
		/*
		 * Create transitions and add new states if necessary
		 */
		for(int i=0; i<input.input_alphabet_size; i++) {
		
			/*
			 * If a transitions with a blank symbol exists, add a self loop
			 */
			if(i == blank_symbol) {
				
				// Search for a blank symbol
				bool blank_found = false;
				for(std::set<int>::const_iterator it=states[cur_state].begin(); it!=states[cur_state].end(); it++) {
					
					//std::cout << "State:" <<  *it <<std::endl;
				
					std::map<int, std::map<int, std::set<int> > >::const_iterator dest_it = input.transitions.find(*it);
                                        if(dest_it != input.transitions.end()) {

                                                if(dest_it->second.count(blank_symbol) > 0) {
                                                        blank_found = true;
                                                        break;
                                                }

                                        }
					
				}
				
				// If transition with blank symbol exists, create self loop
				if(blank_found) {
					transitions[cur_state][blank_symbol].insert(cur_state);
				}
			}
		
			/*
			 * Process non-blank symbols
			 */
			else {

				// The set of states of the old automaton reachable by an i transition
				std::set<int> next_state;
			
				// First, do the standard powerset construction
				for(std::set<int>::const_iterator it=states[cur_state].begin(); it!=states[cur_state].end(); it++) {
					
					// Find destination on i transition
					std::map<int, std::map<int, std::set<int> > >::const_iterator dest_it1 = input.transitions.find(*it);
					if(dest_it1 != input.transitions.end()) {
					
						std::map<int, std::set<int> >::const_iterator dest_it2 = dest_it1->second.find(i);
						if(dest_it2 != dest_it1->second.end()) {
							next_state.insert(dest_it2->second.begin(), dest_it2->second.end());
						}
					}
					
				}
			
				// Second, make the closure on the blank symbol
				next_state = closure(next_state, input, blank_symbol);
				
				// ID of next state
				int next_state_id;
				
				// Add state if not existing (using lambda functionality of C++ 11)
				auto next_state_it = find_if(states.begin(), states.end(), [& next_state] (std::pair<const int, std::set<int> > & p) -> bool { return p.second == next_state; });
				if(next_state_it == states.end()) {
					
					// Create new state
					next_state_id = states.size();
					states[next_state_id] = next_state;
					
					// Mark state to be processed
					if(find(queue.begin(), queue.end(), next_state_id) == queue.end()) {
						queue.push_back(next_state_id);
					}
					
				}
				
				// State already exists
				else {
				
					next_state_id = next_state_it->first;
					
				}

				// Finally, add the transition
				transitions[cur_state][i].insert(next_state_id);

			}
				
		}
	}
	
	
	/*
	 * Create result automaton
	 */
	libalf::moore_machine<type> result;
	result.input_alphabet_size = input.input_alphabet_size;
	result.state_count = states.size();
	result.transitions = transitions;
	result.initial_states.insert(0);
	result.output_mapping = output_mapping;
	result.is_deterministic = true;
	result.valid = true;
	
	return result;
}

/**
 * Takes a Moore machine and removes all states that have a particular (error)
 * output, which is specified by the <tt>error</tt> parameter. Moreover,
 * transition leading to states with an error outout are also deleted. This may
 * result in Moore machines that are no longer connected. Use the
 * remove_unreachable_states(const libalf::moore_machine<answer> &) method to
 * get rid of the unreachable states.
 *
 * @param machine The Moore machine to strip error states from
 * @param error The output symbol of the Moore machine that is regarded as error
 *              symbol
 *
 * @return Returns a Moore machine that does not contain any error output symbol
 *         and, hence, no transition to such a state.
 */
template <class answer>
libalf::moore_machine<answer> strip_error_states(const libalf::moore_machine<answer> & machine, const answer & error) {

	assert(machine.is_valid());

	// Create new states since we only want to keep non-error states (and such that have a output assigned)
	std::map<int, int> new_states; // Maps old state to new states
	int state_count = 0;
	for(int i=0; i<machine.state_count; i++) {
		typename std::map<int, answer>::const_iterator it = machine.output_mapping.find(i);
		if(it != machine.output_mapping.end() && it->second != error) {
			new_states[i] = state_count;
			state_count++;
		}
	}
	
	// Copy transitions
	std::map<int, std::map<int, std::set<int> > > transitions;
	for(std::map<int, std::map<int, std::set<int> > >::const_iterator it1=machine.transitions.begin(); it1!=machine.transitions.end(); it1++) {

		// Skip state if it is an error state
		if(new_states.count(it1->first) == 0) {
			continue;
		}
	
		// Copy transitions if it does not point to an error state
		for(std::map<int, std::set<int> >::const_iterator it2=it1->second.begin(); it2!=it1->second.end(); it2++) {
			for(std::set<int>::const_iterator it3=it2->second.begin(); it3!=it2->second.end(); it3++) {
			
				if(new_states.count(*it3) > 0) {
					transitions[new_states[it1->first]][it2->first].insert(new_states[*it3]);
				}
			
			}
		}
	
	}
	
	// Create initial states
	std::set<int> initial_states;
	for(std::set<int>::const_iterator it=machine.initial_states.begin(); it!=machine.initial_states.end(); it++) {
		if(new_states.count(*it) > 0) {
			initial_states.insert(new_states[*it]);
		}
	}
	
	// Create output mapping
	std::map<int, answer> output_mapping;
	for(typename std::map<int, answer>::const_iterator it=machine.output_mapping.begin(); it!=machine.output_mapping.end(); it++) {
		if(new_states.count(it->first) > 0) {
			output_mapping[new_states[it->first]] = it->second;
		}
	}
	
	// Create automaton
	libalf::moore_machine<answer> result;
	result.input_alphabet_size = machine.input_alphabet_size;
	result.state_count = state_count;
	result.transitions = transitions;
	result.initial_states = initial_states;
	result.output_mapping = output_mapping;
	result.valid = true;
	
	assert(result.is_valid());
	
	return result;
}


/**
 * Takes a Moore machine and constructs a copy where all states that are not
 * reachable from the initial states are removed (including corresponding
 * transitions).
 *
 * @param machine A Moore machine
 * 
 * @return Returns a version of the input Moore machine that only contains
 *         states reachable from the initial states.
 */
template <class answer>
libalf::moore_machine<answer> remove_unreachable_states(const libalf::moore_machine<answer> & machine) {

	assert(machine.is_valid());

	// Compute reachable states
	std::set<int> reachable_states;
	std::list<int> queue;
	queue.insert(queue.begin(), machine.initial_states.begin(), machine.initial_states.end());
	while(!queue.empty()) {
	
		// Get next state
		int current_state = queue.front();
		queue.pop_front();
		reachable_states.insert(current_state);
		
		std::map<int, std::map<int, std::set<int> > >::const_iterator it1 = machine.transitions.find(current_state);
		if(it1 != machine.transitions.end()) {
			for(std::map<int, std::set<int> >::const_iterator it2=it1->second.begin(); it2!=it1->second.end(); it2++) {
				for(std::set<int>::const_iterator it3=it2->second.begin(); it3!=it2->second.end(); it3++) {
					
					if(reachable_states.count(*it3) == 0 && find(queue.begin(), queue.end(), *it3) == queue.end()) {
						queue.push_back(*it3);
					}
					
				}
			}
		
		}
	
	}

	// Create new states
	std::map<int, int> new_states; // Maps old state to new states
	unsigned int state_count = 0;
	for(std::set<int>::const_iterator it=reachable_states.begin(); it!=reachable_states.end(); it++) {
		new_states[*it] = state_count;
		state_count++;
	}
	
	// Copy transitions
	std::map<int, std::map<int, std::set<int> > > transitions;
	for(std::map<int, std::map<int, std::set<int> > >::const_iterator it1=machine.transitions.begin(); it1!=machine.transitions.end(); it1++) {

		// Skip state if it is not reachable
		if(new_states.count(it1->first) == 0) {
			continue;
		}
	
		// Copy transitions
		for(std::map<int, std::set<int> >::const_iterator it2=it1->second.begin(); it2!=it1->second.end(); it2++) {
			for(std::set<int>::const_iterator it3=it2->second.begin(); it3!=it2->second.end(); it3++) {

				transitions[new_states[it1->first]][it2->first].insert(new_states[*it3]);
			
			}
		}
	
	}
	
	// Input states
	std::set<int> initial_states;
	for(std::set<int>::const_iterator it=machine.initial_states.begin(); it!=machine.initial_states.end(); it++) {
		assert(new_states.count(*it) > 0);
		initial_states.insert(new_states[*it]);
	}
	
	// Create output mapping
	std::map<int, answer> output_mapping;
	for(typename std::map<int, answer>::const_iterator it=machine.output_mapping.begin(); it!=machine.output_mapping.end(); it++) {
		if(new_states.count(it->first) > 0) {
			output_mapping[new_states[it->first]] = it->second;
		}
	}
	
	// Create automaton
	libalf::moore_machine<answer> result;
	result.input_alphabet_size = machine.input_alphabet_size;
	result.initial_states = initial_states;
	result.state_count = state_count;
	result.transitions = transitions;
	result.output_mapping = output_mapping;
	result.valid = true;
	
	assert(result.is_valid());
	
	return result;
}

/**
 * We assume that states with the error type are sink states, i.e., we do not
 * traverse transitions leading to states with the error type.
 */
template <class answer>
bool __is_correctly_typed(const libalf::moore_machine<answer> & machine, std::list<int> & ce, int state, std::set<int> occurred_variables, bool * visited) {

	// End of recursion
	if(visited[state]) {
		return true;
	} else {
		visited[state] = true;
	}

	// Check for any transition whether a variable occurs that already occured before
	std::map<int, std::map<int, std::set<int> > >::const_iterator it1 = machine.transitions.find(state);
	if(it1 != machine.transitions.end()) {
	
		// For every input symbol
		for(std::map<int, std::set<int> >::const_iterator it2=it1->second.begin(); it2!=it1->second.end(); it2++) {
		
			// The variables encoded by the current transition
			std::set<int> current_variables;
		
			/*
			 * Decode input symbol (adapted from Pranav's code)
			 */
			int symbol = it2->first;
			int variable = 0;
			while (symbol != 0) {
				if (symbol % 2) {
					current_variables.insert(variable);
				}
				symbol = symbol / 2;
				variable++;
			}
			
			/*
			 * Check whether the current symbol would make the automaton incorrecly typed
			 */
			bool incorrectly_typed = false;
			for(std::set<int>::const_iterator it3=current_variables.begin(); it3!=current_variables.end(); it3++) {
				if(occurred_variables.count(*it3) > 0) {
					incorrectly_typed = true;
					break;
				}
			}

			#if 1
			std::cout << "Transition: (" << it1->first << ", " << it2->first << ")\tCurrent variables: [";
			for(std::set<int>::const_iterator bla=occurred_variables.begin(); bla!=occurred_variables.end(); bla++) {
				std::cout << *bla << " ";
			}
			std::cout << "]\tNew variables: [";
			for(std::set<int>::const_iterator bla=current_variables.begin(); bla!=current_variables.end(); bla++) {
				std::cout << *bla << " ";
			}
			std::cout << "]\tIncorrectly typed? " << incorrectly_typed << std::endl;
			#endif
			
			// Insert current variables into occurred variables (for recursive calls)
			occurred_variables.insert(current_variables.begin(), current_variables.end());
			
			/*
			 * If all transitions lead to error states, then being incorrectly
			 * typed is not a problem. If this is not the case, we found a
			 * problem and report a counter-example. We do not follow
			 * transitions to error states.
			 */
			if(incorrectly_typed) {
			
				// Make sure that all destinations with this symbol are error states
				for(std::set<int>::const_iterator it3=it2->second.begin(); it3!=it2->second.end(); it3++) {
				
					std::map<int, type>::const_iterator it4 = machine.output_mapping.find(*it3);
					if(it4 == machine.output_mapping.end() || it4->second != type::error_type()) {
						
						// Found destination that is no error state. Construct counter-example.
						ce.push_front(it2->first);
						return false;
						
					}
				
				}
			
			}
			
			// The transition makes no problems, hence, simply traverse the transitions
			else {
			
				for(std::set<int>::const_iterator it3=it2->second.begin(); it3!=it2->second.end(); it3++) {
				
					// Skip transition to error state
					std::map<int, type>::const_iterator it4 = machine.output_mapping.find(*it3);
					if(it4 != machine.output_mapping.end() && it4->second == type::error_type()) {
						continue;
					}

					// Traverse
					//std::cout << "Recursive call ... " << std::endl;
					if(!__is_correctly_typed(machine, ce, *it3, occurred_variables, visited)) {
						
						// Construct counter-example.
						ce.push_front(it2->first);
						return false;
						
					}
					
				}

			}
			
		}
	
	}

	return true;
}
	

/**
 * Checks whether a Moore machine is correctly typed. If this is not the case,
 * then a counter-example is returned.
 */
template <class answer>
bool is_correctly_typed(const libalf::moore_machine<answer> & machine, std::list<int> & ce) {

	// Prepare array of visited states in the product
	bool * visited = new bool [machine.state_count];
	memset(visited, false, machine.state_count * sizeof(bool));

	// Start from any initial state
	bool correctly_typed = true;
	for(std::set<int>::const_iterator it=machine.initial_states.begin(); it!=machine.initial_states.end(); it++) {
		std::set<int> occurred_variables;
		if(!__is_correctly_typed(machine, ce, *it, std::set<int>(), visited)) {
			correctly_typed = false;
			break;
		}
	}

	// Delete visited array
	delete[] visited;
	
	return correctly_typed;
}
#endif
