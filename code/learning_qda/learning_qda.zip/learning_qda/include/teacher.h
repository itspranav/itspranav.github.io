/**
 * \file teacher.h
 *
 * This file defines teachers for data languages. It provides a pure
 * virtual class defining the general interface of a teacher. In order to use
 * the learn(teacher & t, unsigned int alphabet_size) method in the file
 * learner.h, a user has to implement its own teacher by implementing the
 * teacher interface.
 *
 * @author Daniel Neider
 * @version 1.0
 */

#ifndef __TEACHER_H__
#define __TEACHER_H__

#include <list>

#include "types.h"

#include "libalf/conjecture.h"

/**
 * This is a pure virtual class that defines the interface for a teacher in the
 * context of learning data languages. In particular, it defines the signature
 * for membership and equivalence queries.
 *
 * This interface abstracts from a concrete representation of an alphabet. An
 * implementation of a teacher should take care of the alphabet (or alphabet
 * size) by itself.
 *
 * @author Daniel Neider
 * @version 1.0
 */
class teacher {

	public:

	/**
	 * Answers a membership query for the given word. A word is a sequence of
	 * integers where each such integer represents a symbol of the alphabet.
	 * The answer to a membership query is a \ref type object.
	 *
	 * Note that there is no mechanism to prevent invalid queries, i.e., queries
	 * with symbols that are out ouf bounds. Nontheless, a teacher should answer
	 * queries with invalid symbols consistently with some sort of default
	 * answer, e.g., a type that only occurs at a sink state. The learner,
	 * however, will never ask invalid queries (unless you change the alphabet
	 * size during the learning process).
	 *
	 * @param word A query
	 *
	 * @return Returns the type of the given word.
	 */
	virtual type membership_query(std::list<int> & word) const = 0;
	
	/**
	 * Answers an equivalence query for the given conjecture. The conjecture is
	 * a Moore machine that outputs a \ref type object.
	 *
	 * This method shall return true if the Moore machine is equivalent to the
	 * target language and false otherwise. If false is returned, then a
	 * counter-example has to be provided. This counter-example is stored as the
	 * <tt>ce</tt> parameter.
	 * Note that an implementation might alter the <tt>ce</tt> parameter even if
	 * the method returns true.
	 *
	 * Finally, a teacher should ignore the behavior of a conjecture on words
	 * that contain invalid symbols. Again, a learner will provide a conjecture
	 * that has transitions with invalid symbols (unless you change the alphabet
	 * size during the learning process).
	 *
	 * @param conjecture The conjecture to check for equivalence
	 * @param ce If the conjecture is not equivalent to the target language,
	 *           this parameter is used to pass a counter-example back to the
	 *           learning algorithm.
	 *
	 * @return Returns true if the conjecture is equivalent to the target
	 *         language and false otherwise.
	 */
	virtual bool equivalence_query(const libalf::moore_machine<type> & conjecture, std::list<int> & ce) const = 0;

};

#endif
