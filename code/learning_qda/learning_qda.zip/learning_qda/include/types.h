/**
 * \file types.h
 *
 * This file defines classes used as output symbol of Moore machines. Currently,
 * we use two different types as output symbols: a strong_y_type and a
 * data_type. Both are derived from a pure virtual class abstract_type.
 *
 * Since libalf cannot handle pure virtual classes as output symbols (it uses
 * references to objects rather than pointers), we have to use a wrapper class
 * (see the class \ref type) to encapsulate an anstract_type.
 *
 * @author Daniel Neider
 * @version 1.0
 */

#ifndef __TYPES_H__
#define __TYPES_H__

#include <iostream>
#include <sstream>
#include <set>
#include <vector>
#include <algorithm>
#include <map>
#include "assert.h"
#include <stdlib.h>

extern std::vector<std::string> data_formulas;


class abstract_type {

	public:

	#ifdef SIMPLE_Y_TYPE
	std::set<unsigned int> y_type;

	#else	
       	/*
         * Stores the strong y_type: set of variables that have already occurred 
         * together with the information which variables occurred at the same time.
	 */
	std::set<unsigned int> y_type;
	#endif

	std::vector<bool> d_type;
	
	/*
	 * Creates an empty object with y_type is empty set and d_type is empty vector.
	 */
	abstract_type() {
	}
	
	
	/*
	 * Creates an object with the y_type as that passed as argument.
	 */
	#ifdef SIMPLE_Y_TYPE
	abstract_type(const std::set<unsigned int> & y_type) : y_type(y_type) {
	}
	#else
	abstract_type(const std::set<unsigned int> & y_type) : y_type(y_type) {
	}
	#endif


	/**
	 * Creates a new data_type object containing the given y_type and d_type
	 *
	 * @param y_type The y_type to store
	 * @param d_type The data type to store
	 */
	#ifdef SIMPLE_Y_TYPE
	abstract_type(const std::set<unsigned int> & y_type, const std::vector<bool> & d_type) : y_type(y_type), d_type(d_type) {
	}
	#else
	abstract_type(const std::set<unsigned int> & y_type, const std::vector<bool> & d_type) : y_type(y_type), d_type(d_type) {
	}
	#endif

	/**
	 * Creates a copy of the given data_type object (copy constructor).
	 *
	 * @param other The object to copy
	 */
	abstract_type(const abstract_type & other) {
		this->y_type = other.y_type;
		this->d_type = other.d_type;
	}
	
	/**
	 * Destructor.
	 */
	~abstract_type() {
	}


	/*
	 * Implements the method abstract_type::clone().
	 */
	abstract_type * clone() const {
		return new abstract_type(y_type, d_type);
	}
	
	/*
	 * Implements the method abstract_type::operator==(const abstract_type & other).
	 */
	bool operator==(const abstract_type & other) const {
	
		return ((y_type == other.y_type) && (d_type == other.d_type));
	
	}
	
	/**
	 * Checks whether two abstract types are not equal.
	 *
	 * @param other The other object to compare this object with
	 *
	 * @return Returns true if both objects are not the same and true otherwise.
	 */
	bool operator!=(const abstract_type & other) const {
		return !(*this == other);
	}
	

	/*
	 * Implements the method abstract_type::to_string().
	 */
	std::string to_string() const {
		std::stringstream s;

		// Output y type
		unsigned int l=0;
		s << " {";
		for(std::set<unsigned int>::const_iterator it1=y_type.begin(); it1!=y_type.end(); it1++) {
			
			s << *it1 << ", ";// << (l<it1->size()-1 ? ", " : "");
			l++;
			
		}
		s << "};";

		// Output data type
		s << " [";
		for(std::vector<bool>::const_iterator it=d_type.begin(); it!=d_type.end(); it++) {
			s << *it;
		}
		s << "]";
		
		#if 0
		if(d_type.size() != 0) { 
			assert(d_type.size() == (2 * data_formulas.size()));
			for (i = 0; i < data_formulas.size(); i++) {
				if (d_type[2*i] && d_type[2*i+1]) {
					; // data_type = 11 (Top)
			
				} else if (d_type[2*i] && !d_type[2*i+1]) {
					s << " (" << data_formulas[i].c_str() << ")";
					// data_type = 10 (True)

				} else if (!d_type[2*i] && d_type[2*i+1]) {
					s << " !(" << data_formulas[i].c_str() << ")";
					// data_type = 01 (False)
				
				} else if (!d_type[2*i] && !d_type[2*i+1]) {
					; 
					// data_type = 00 (Bot)
  
				} 
			}
		} 
		#endif

		return s.str();
	}
};



/**
 * This class is a wrapper for an abstract_type object. Since libalf stores
 * references in its knowledgebase and abstract_type is a pure virtual class
 * (i.e., an interface), which cannot be instantiated, a wrapper is needed.
 *
 * A type object contains a pointer to a single abstract_type object. All method
 * calls are passed on to the abstract_type object. However, a \ref type object
 * might also be <em>empty</em>, i.e., its pointer points to NULL rather than to
 * an abstract_type object. This is a special but also valid \ref type object,
 * which might be useful to represent a sink.
 *
 * In order to use a \ref type object as output of a Moore machine in libALF,
 * it has to implement the following methods:
 * - operator<<(std::ostream & out, type const & t)
 * - type::operator==(const type & other) const
 * - type::operator=(const type & other)
 * - type::operator=(const bool b)
 *
 * Also, we need to implement the methods
 * deserialize(type & t, serial_stretch & serial) and serialize(const type & t),
 * However, since we do not want to use libALF's serialization functionality,
 * these are empty implementations.
 *
 * @author Daniel Neider
 * @version 1.0
 */
class type {

	/**
	 * A pointer to a concrete implementation of an abstract type.
	 */
	public: abstract_type * ptr;
	
	public:
	
	/**
	 * Creates a new (and empty) type object.
	 */
	type() {
		ptr = NULL;
	}

	/**
	 * Creates a new type object as a wrapper for the given abstract_type
	 * object. The other object is thereby copied.
	 *
	 * @param other An abstract_type object, of which a copy is stored
	 */
	type(const abstract_type & other) {
		ptr = other.clone();
	}

	/**
	 * Creates a copy of the given type object (copy constructor).
	 *
	 * @param other The object to copy
	 */
	type(const type & other) {
		if(other.ptr == NULL) {
			ptr = NULL;
		} else {
			ptr = other.ptr->clone();
		}
	}
	
	/**
	 * Destructor.
	 */
	~type() {
		if(ptr) {
			delete ptr;
		}
	}

	/**
	 * Returns a string representation of this object.
	 *
	 * @return Returns a string representation of this object.
	 */
	std::string to_string() const {
		if(ptr==NULL) {
			return "NULL";
		} else {
			return ptr->to_string();
		}
	}
	
	/**
	 * Checks whether two type objects are equal.
	 *
	 * @param other The other object to compare this object with
	 *
	 * @return Returns true if both objects are the same and false otherwise.
	 */
	bool operator==(const type & other) const {
		if(ptr==NULL && other.ptr==NULL) {
			return true;
		} else if(ptr==NULL || other.ptr==NULL) {
			return false;
		} else {
			return (*ptr) == (*other.ptr);
		}
	}
	
	/**
	 * Checks whether two types are not equal.
	 *
	 * @param other The other object to compare this object with
	 *
	 * @return Returns true if both objects are not the same and true otherwise.
	 */
	bool operator!=(const type & other) const {
		return !(*this == other);
	}
	
	/**
	 * Assigns the data of the type object given as <tt>rhs</tt> parameter to
	 * this object. The data currently stored in this objects is deleted and the
	 * data of the <tt>rhs</tt> object is copied.
	 *
	 * @param rhs the right hand site of this assignment, i.e., the object whose
	 *            data should be assigned to the left hand side object
	 *
	 * @return Returns a reference to this object.
	 */
	type & operator=(const type & rhs) {
		
		// Delete current object
		if(ptr) {
			delete ptr;
		}

		// Check whether right hand side is an empty wrapper
		if(rhs.ptr==NULL) {
			ptr = NULL;
			return *this;
		}
		
		// If the wrapper is not empty, copy abstract_type object
		ptr = rhs.ptr->clone();
		return *this;
	}


	/**
	 * An operator that assigns a Boolean value to this object. This operator
	 * deletes the current content of the left hand side object and creates an
	 * empty type object.
	 *
	 * Note that this method is only necessary to make type objects work with
	 * libALF's normalizer. This implementation has no other purpose and simply
	 * does "something". If you do not understand a word, just ignore it since
	 * we are not going to use normalizers.
	 *
	 * @param b The Boolean to assign
	 *
	 * @return Returns a reference to tis object.
	 */
	type & operator=(__attribute__((__unused__)) const bool b) {
	
		if(ptr) {
			delete ptr;
		}
		ptr=NULL;
	
		return *this;
	}


	/**
	 * Returns a special type that is used as the error type.
	 *
	 * @return Returns the error type.
	 */
	static type error_type() {
		return type();
	}
	
};

/**
 * << operator for the \ref type wrapper class. This is necessary to make the
 * libALF's conjecture::visualize() method work. This method calls
 * type::to_string().
 *
 * @param out The output stream to write to
 * @param t The \ref type object to write
 *
 * @return Returns the output stream given by <tt>out</tt>.
 */
std::ostream & operator<<(std::ostream & out, type const & t) {
	out << t.to_string();
	return out;
}


/*
 * The following code is necessary to make libalf work with type objects. These
 * functions are used to serialize and deserialize such objects, but since we
 * do not use this functionality, we only provide "empty" implementations.
 */

#include "libalf/serialize.h"
/**
 * An empty implementation of libALF's deserialize function for \ref type
 * objects.
 *
 * @param t The type to deserialize
 * @param serial The serial stretch from which the data is read
 *
 * @return Returns always false.
 */
bool deserialize(__attribute__((__unused__)) type & t, __attribute__((__unused__)) serial_stretch & serial) {
	return false;
}

/**
 * An empty implementation of libALF's serialize function for \ref type objects.
 *
 * @param t The type to serialize
 *
 * @return Returns an empty string.
 */
std::basic_string<int32_t> serialize(__attribute__((__unused__)) const type & t) {
	std::basic_string<int32_t> ret;
	return ret;
}


/**
 * This pure virtual class defines the interface for computing joins in an
 * (abstract) lattice.
 *
 * @author Daniel Neider
 * @version 1.0
 */
class data_type_join {

	public:
	virtual void join(const type & first, const type & second, type & result) const = 0;

};

/*
 * Given two boolean vectors as arguments, a join is their bitwise logical_or.
 */
class simple_test_join : public data_type_join {
	
	public:
	
	/*
	 * Implements data_type_join::join(const type & first, const type & second, type & result)
	 */
	
	void join(const type & first, const type & second, type & result) const {

		// Check whether both types are abstract
		abstract_type * first_type = dynamic_cast<abstract_type *>(first.ptr);
		if(!first_type) {
			result = type();
			return;
		}
		abstract_type * second_type = dynamic_cast<abstract_type *>(second.ptr);
		if(!second_type) {
			result = type();
			return;
		}
		
		// Check whether both types have the same y type
		assert(first_type->y_type == second_type->y_type);
		if(first_type->y_type != second_type->y_type) {
			result = type();
			return;
		}
		
		/* If the two operands have d_type (vector<bool>) of different sizes, then
		 * resize the smaller vector to the size of the larger vector.
		 */
		std::vector<bool> op1 = first_type->d_type;
		std::vector<bool> op2 = second_type->d_type;
		if(op1.size() > op2.size()) {
                        op2.resize(op1.size(), false);

                } else {
                        op1.resize(op2.size(), false);
                }

		abstract_type * result_type = dynamic_cast<abstract_type *>(result.ptr);
		if(!result_type) {
			std::cerr << "Argument to method join not of type abstract_type" << std::endl;
			exit(1);
		}

		// Compute the d_type of the join
		result_type->d_type.resize(op1.size(), false);
                std::transform(op1.begin(), op1.end(), op2.begin(), result_type->d_type.begin(), std::logical_or<bool>());

		// Initialize the y_type of the join as the y_type of any of the operands.
		result_type->y_type = first_type->y_type;
	
		return; 
	}

};

#endif

