#include <fstream>
#include <string>
#include <sstream>

#include <stddef.h>

extern "C" {
#include "cmap.h"
#include "file_tools.h"
}

int read_implications(const char * filename, cmap * map) {

	if(filename == NULL || map == NULL) {
		return false;
	}

	// Open file
	std::ifstream infile;
	infile.open(filename);

	if(!infile.is_open()) {
		return false;
	}

	// Read line by line
	std::string line;
	while (std::getline(infile, line)) {

		// Comments
		if(line.size() == 0 || line[0] == '#') {
			continue;
		}

		// Read line
		std::istringstream iss(line);
		int x, y;
		if ((iss >> x >> y)) {

			// Add to map
			cmap_add(map, x, y);

		}

	}

	// Close file
	infile.close();

	return true;

}
