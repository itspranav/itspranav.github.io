/*
 * This code takes a comma separated list of attributes (each line is
 * interpreted as one case) and randomly adds implications. In order to do so,
 * the cases taking part in an implication are turned into unclassified cases.
 * This requires that the class attribute is binary (which value is positive and
 * which negative can be specified); also, the position of the class attribute
 * in a line can be specified.
 * 
 * There are two different types of implications:
 *
 * 1) Simple implications (i.e., simply an implication); can be + => +, - => -,
 *    - => + (the probabilities of these types can be specified)
 *
 * 2) Implications chains + => + => + => ... (the length is drawn
 *    probabilistically)
 *
 * Most stuff can be parameterized by of parameters. Run the program with -h
 * parameter to get help.
 *
 * WARNING: If you specify to many implications, the program might run out of
 *          cases to turn from classified to unclassified. This is NOT checked
 *          (and happens usually with positive cases). If this happens, the
 *          program terminates with an error. 
 */

#include <algorithm>
#include <chrono>
#include <iostream>
#include <fstream>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#include <assert.h>
#include <unistd.h>
#include <stdlib.h>

// Default output for implications (can be overridden from command line)
#define UNCLASSIFIED_VALUE "2"

// Probability to choose the left or right hand side from a class that
// already occurs in an implicaton (can be overridden from command line)
#define UNCLASSIFIED_PROBABILITY 10


const std::string WHITESPACE = " \n\r\t";

inline std::string trimLeft(const std::string& s) {
    size_t startpos = s.find_first_not_of(WHITESPACE);
    return (startpos == std::string::npos) ? "" : s.substr(startpos);
}

inline std::string trimRight(const std::string& s) {
    size_t endpos = s.find_last_not_of(WHITESPACE);
    return (endpos == std::string::npos) ? "" : s.substr(0, endpos+1);
}

inline std::string trim (const std::string& s) {
    return trimRight (trimLeft (s));
}


/*
 * Chooses a case uniformly randomly from a resp. b. If it was chosen
 * from a, it is moved to b. The parameter p is probabilty to choose
 * from b (if nonempty).
 */ 
int draw_case (std::vector<int> & a, std::vector<int> & b, int p) {

		std::default_random_engine generator(std::chrono::system_clock::now().time_since_epoch().count());
		std::uniform_int_distribution<int> uniform_0to100(0, 100);

		int case_no;
		if (b.size() > 0 && uniform_0to100(generator) < p) {
			
			std::uniform_int_distribution<int> tmp_dist(0, b.size() - 1);
			case_no = b[tmp_dist(generator)];

		} else {

			// Check whether there are classified cases left
			//assert (a.size() > 0);
			if (a.size() == 0) {

				std::cerr << "No classified cases left! Exiting ..." << std::endl;
				exit (EXIT_FAILURE);

			}


			std::uniform_int_distribution<int> tmp_dist(0, a.size() - 1);
			case_no = a[tmp_dist(generator)];

			// Move from a to b
			std::vector<int>::iterator rm_it = std::find(a.begin(), a.end(), case_no);
			assert(rm_it != a.end());
			a.erase(rm_it);
			b.push_back(case_no);

		}

		return case_no;

}


/**
 * Creates implications by randomly choosing positive or negative cases
 * an moving them from positive (negative) to pos_impl (neg_impl).
 * 
 * @param positive Set of positive examples
 * @param negative Set of negative examples
 * @param implications The resulting set of implications
 * @param pos_impl Set of (now) unclassified cases that take positively part in an implication
 * @param neg_impl Set of (now) unclassified cases that take negatively part in an implication
 * @param number Number of implications to produce
 * @param a The a parameter from the input (prob. of + => + implication)
 * @param b The b parameter from the input (prob. of - => - implication)
 * @param p the probability that a implication is produced from an already existing implication (0 <= p <= 100)
 */
void draw_simple_implications (std::vector<int> & positive, std::vector<int> & negative, std::set<std::pair<int, int> > & implications, std::vector<int> & pos_impl, std::vector<int> & neg_impl, int number, int a, int b, int p) {

	assert(p >= 0 && p <= 100);

	// Create random number generators
	std::default_random_engine generator(std::chrono::system_clock::now().time_since_epoch().count());
	std::uniform_int_distribution<int> uniform_0to100(0, 100);

	for (int i=0; i<number; i++) {

		// Type of implication
		int rnd = uniform_0to100(generator);
		// + => +
		if (rnd <= a) {

			int left = draw_case (positive, pos_impl, p);
			int right = draw_case (positive, pos_impl, p);
			implications.insert(std::pair<int, int> (left, right));

		}

		// - => -
		else if (rnd <= a+b) {

			int left = draw_case (negative, neg_impl, p);
			int right = draw_case (negative, neg_impl, p);
			implications.insert(std::pair<int, int> (left, right));

		}

		// - => +
		else {

			int left = draw_case (negative, neg_impl, p);
			int right = draw_case (positive, pos_impl, p);
			implications.insert(std::pair<int, int> (left, right));
		}

		//std::cout << "Size: " << implications.size() << std::endl;

	}

}


/**
 * Creates chains of + => + implications, potentially marking classified cases to
 * as unclassified. The length of these chaines is modeled as a  
 * 
 * @param positive Set of positive examples
 * @param negative Set of negative examples
 * @param implications The resulting set of implications
 * @param pos_impl Set of (now) unclassified cases that take positively part in an implication
 * @param neg_impl Set of (now) unclassified cases that take negatively part in an implication
 * @param number Number of implications to produce
 * @param l The probability used to determine the length of an implication chain.
 * @param p the probability that a implication is produced from an already existing implication (0 <= p <= 100)
 * @returns Returns a pair: first entry is the max. length of a chain, sencond entry is the avarage length
 */
std::pair<int, float> draw_implication_chains (std::vector<int> & positive, std::vector<int> & negative, std::set<std::pair<int, int> > & implications, std::vector<int> & pos_impl, std::vector<int> & neg_impl, int number, int l, int p) {

	assert(l >= 0 && l <= 100);
	assert(p >= 0 && p <= 100);

	// Create random number generators
	std::default_random_engine generator(std::chrono::system_clock::now().time_since_epoch().count());
	std::geometric_distribution<int> geo_distribution(((float)l) / 100);

	int max = 0;
	int sum = 0;

	// Create chains
	for (int i=0; i<number; i++) {

		// Draw length
		int len = 1 + geo_distribution(generator);

		// Statistics
		sum += len;
		if (len > max) {
			max = len;
		}

		// Draw chain
		int last_case = draw_case (positive, pos_impl, p);
		for (int j=0; j<len; j++) {

			int next_case = draw_case (positive, pos_impl, p);
			implications.insert (std::pair<int, int> (last_case, next_case));
			last_case = next_case;

		}

	}

	return std::pair<int, float>(max, ((float)sum)/((float)number));

}


/*
 * Writes a case to an output stream.
 *
 * @param out The output stream to write the case to
 * @param line The case to write
 * @param implication If true, then the class attribute is set to
 *                    unclassified_value
 * @param class_attribute_pos The position of the class attribute
 * @param unclassified_value The value to assign the class attribute of
 *                           unclassified cases to
 */
void write_case (std::ostream & out, std::vector<std::string> & line, bool implication, int class_attribute_pos, std::string & unclassified_value) {

	int i = 0;
	for (std::vector<std::string>::iterator it = line.begin(); it != line.end(); it++, i++) {

		if (i > 0) {
			out << ",";
		}

		if (implication && i == class_attribute_pos) {
			out << unclassified_value;
		} else {
			out << *it;
		}

	}

	out << std::endl;

}


/*
 * Check whether the drawn implications can are satisfied by the original
 * classification.
 */
bool check_implications (std::vector<std::vector<std::string> > & cases, std::set<std::pair<int, int> > & implications, int class_attribute_pos, std::string & n_attr, std::string & p_attr) {

	for (std::set<std::pair<int, int> >::iterator it = implications.begin(); it != implications.end(); it++) {

		assert (n_attr.compare(cases[it->first][class_attribute_pos]) == 0 || p_attr.compare(cases[it->first][class_attribute_pos]) == 0);
		bool left = p_attr.compare(cases[it->first][class_attribute_pos]) == 0;

		assert (n_attr.compare(cases[it->second][class_attribute_pos]) == 0 || p_attr.compare(cases[it->second][class_attribute_pos]) == 0);
		bool right = p_attr.compare(cases[it->second][class_attribute_pos]) == 0;

		assert (!left || right);	

	}

	return true;

}


/*
 * Prints a help message to std::cout
 */
void print_help (const char * arg) {

	std::cout << "Usage: " << arg << " [options]" << std::endl;

	std::cout << std::endl << "General options:" << std::endl;
	std::cout << " h\t\t\tDisplays this help message" << std::endl;

	std::cout << std::endl << "Input options:" << std::endl;
	std::cout << " c\tnumber\t\t" << "The position in of the class attribute (can be 'last')" << std::endl;
	std::cout << " i\tfilename\t" << "Filename of the input file" << std::endl;
	std::cout << " n\tstring\t\t" << "The the negative class attribute (defaults to '0')" << std::endl;
	std::cout << " p\tstring\t\t" << "The the positive class attribute (defaults to '1')" << std::endl;

	std::cout << std::endl << "Implication options:" << std::endl;
	std::cout << " f\tnumber\t\t" << "The number of simple implications to produce given" << std::endl << "\t\t\tas percentage of the total number of cases" << std::endl << "\t\t\t(0 <= f <= 100)" << std::endl;
	std::cout << " g\tnumber\t\t" << "The number of implication chains to produce given" << std::endl << "\t\t\tas percentage of the total number of cases" << std::endl << "\t\t\t(0 <= g <= 100)" << std::endl;
	std::cout << " u\tstring\t\t" << "The value of the class attribute of undefined" << std::endl << "\t\t\tcases (those now taking part in implications, defaults" << std::endl << "\t\t\tto " << UNCLASSIFIED_VALUE << ")" << std::endl; 

	std::cout << std::endl << "Probability options:" << std::endl; 
	std::cout << " a\tnumber\t\t" << "The probability of + => + implications (0 <= a <= 100)" << std::endl;
	std::cout << " b\tnumber\t\t" << "The probability of - => - implications (0 <= b <= 100)" << std::endl;
	std::cout << " l\tnumber\t\t" << "The probability used to draw the length of an" << std::endl << "\t\t\timplication chain (0 <= l <= 100)" << std::endl;
	std::cout << " v\tnumber\t\t" << "The probability of choosing an unclassified case when" << std::endl << "\t\t\tdrawing implications (0 <= v <= 100, defaults to 10)" << std::endl;
	
}


/*
 * Main program
 */ 
int main (int argc, char * argv[]) {

	/*
	 * Variables
	 */
	char * filename = NULL; // Filename for input file
	std::string n_attr; // The attribute representing a negative value
	std::string p_attr; // The attribute representing a positive value
	std::string unclassified_value(UNCLASSIFIED_VALUE); // The value of the class attribute of unclassified cases 
	int class_attribute_pos = -1; // The position of the class attribute within a line
	int numberOfAttributes = 0; // The total number of attributes (must be constant for all cases)
	int a = -1; // Probability of + -> + implication
	int b = -1; // Probability of - -> - implication
	int f = -1; // Number of simple implications given as fraction of the total number of cases
	int g = -1; // Number of implication chains given as fraction of the total number of cases
	int l = -1; // Probability used in length of implication chains
	int v = -1; // Probability of choosing an (later made) unclassified case when drawing implications 

	bool has_n_attr = false; // Stores whether the negative attribute is specified
	bool has_p_attr = false; // Stores whether the positive attribute is specified
	bool class_attribute_is_last = false; // Is true if the class attribute is the last
	bool unclassified_class_attribute_specified = false; // Is true if the class attribute is specified on the command line

	std::vector<std::vector<std::string> > cases; // All cases
	std::vector<int> positive, negative; // Index of positive, respectively negative, cases
	int total_cases = 0; // Total number of cases

	/*
	 * Process command line options
	 */
	int c;
	while ((c = getopt (argc, argv, "a:b:c:f:g:hi:l:n:p:u:v:")) != -1) {

		switch (c) {

			case 'a': {
				std::string tmp1(optarg);
				std::stringstream tmp2(tmp1);
				tmp2 >> a;
				if (a < 0 || a > 100) {

					std::cerr << "Invalid value of parameter a (use 0 <= a <= 100)" << std::endl;
					return EXIT_FAILURE;

				}
			}
			break;

			case 'b': {
				std::string tmp1 = std::string(optarg);
				std::stringstream tmp2(tmp1);
				tmp2 >> b;
				if (b < 0 || b > 100) {

					std::cerr << "Invalid value of parameter b (use 0 <= b <= 100)" << std::endl;
					return EXIT_FAILURE;

				}
				}
				break;

			case 'c': {
				std::string position_option = trim(std::string(optarg));
				if (position_option.compare("last") == 0) {

					class_attribute_is_last = true;
					break;

				} else {

					std::stringstream tmp(position_option);
					tmp >> class_attribute_pos;
					if (class_attribute_pos < 0) {

						std::cerr << "'" << position_option << "' is not a valid position (use n >= 0 or last)" << std::endl;
						return EXIT_FAILURE;

					}

				}
				}
				break;

			case 'f': {
				std::string tmp1 = std::string(optarg);
				std::stringstream tmp2(tmp1);
				tmp2 >> f;
				if (f < 0 || f > 100) {

					std::cerr << "Invalid value of parameter f (use 0 <= f <= 100)" << std::endl;
					return EXIT_FAILURE;

				}
				}
				break;

			case 'g': {
				std::string tmp1 = std::string(optarg);
				std::stringstream tmp2(tmp1);
				tmp2 >> g;
				if (g < 0 || g > 100) {

					std::cerr << "Invalid value of parameter g (use 0 <= f <= 100)" << std::endl;
					return EXIT_FAILURE;

				}
				}
				break;

			case 'h':
				print_help (argv[0]);
				return EXIT_SUCCESS;

			case 'i':
				filename = optarg;
				break;

			case 'l': {
				std::string tmp1 = std::string(optarg);
				std::stringstream tmp2(tmp1);
				tmp2 >> l;
				if (l < 0 || l > 100) {

					std::cerr << "Invalid value of parameter l (use 0 <= l <= 100)" << std::endl;
					return EXIT_FAILURE;

				}
				}
				break;

			case 'n':
				has_n_attr = true;
				n_attr = trim(std::string(optarg));
				break;

			case 'p':
				has_p_attr = true;
				p_attr = trim(std::string(optarg));
				break;

			case 'u': {
				unclassified_value = trim(std::string(optarg));
				unclassified_class_attribute_specified = true;
				if (unclassified_value.length() == 0) {

					std::cerr << "Empty string for unclassified value is not allowed" << std::endl;
					return EXIT_FAILURE;

				}
				}

			case 'v': {
				std::string tmp1 = std::string(optarg);
				std::stringstream tmp2(tmp1);
				tmp2 >> v;
				if (v < 0 || v > 100) {

					std::cerr << "Invalid value of parameter v (use 0 <= v <= 100)" << std::endl;
					return EXIT_FAILURE;

				}
				}
				break;

			default:
				std::cout << "Unrecognized option" << std::endl;
				print_help (argv[0]);
				return EXIT_FAILURE;

		}

	}

	/*
	 * Check options
	 */
	// Mandatory arguments
	if (!filename) {

		std::cerr << "You need to specify a file" << std::endl;
		return EXIT_FAILURE;

	}


	// Optional arguments
	if (!has_n_attr) {

		n_attr = std::string("0");
		std::cout << "Warning, no negative attribute specified (using 0)" << std::endl;

	}
	if (!has_p_attr) {

		p_attr = std::string("1");
		std::cout << "Warning, no positive attribute specified (using 1)" << std::endl;

	}
	if (class_attribute_pos < 0 && !class_attribute_is_last) {

		std::cout << "Warning, no position for class attribute given (using last)" << std::endl;
		class_attribute_is_last = true;

	}
	if (a < 0 && b < 0) {

		std::cout << "Warning, neither a nor b is set (using a=33 and b=33)" << std::endl;
		a = 33;
		b = 33;

	} else if (a < 0 || b < 0) {

		std::cerr << "a and b have to be specified together" << std::endl;
		return EXIT_FAILURE;

	}
	if (a + b > 100) {

		std::cerr << "Sum of a and b has to be less or equal to 100" << std::endl;
		return EXIT_FAILURE;

	}
	if (f < 0) {

		std::cout << "Warning, no fraction for simple implications given (using 0)" << std::endl;
		f = 0;

	}
	if (g < 0) {

		std::cout << "Warning, no fraction for implication chains given (using 0)" << std::endl;
		g = 0;

	}
	if (!unclassified_class_attribute_specified) {

		std::cout << "Warning, value of undefined class attribute not specified (using " << unclassified_value << std::endl;

	}
	if (v < 0) {

		std::cout << "Warning, parameter v not set (using " << UNCLASSIFIED_PROBABILITY << ")" << std::endl;
		v = UNCLASSIFIED_PROBABILITY; 

	}


	/*
	 * Read file
	 */
	// Open file
	std::ifstream infilestream(filename);
	if (!infilestream.is_open()) {

		std::cerr << "Unable to open '" << filename << "'" << std::endl;
		return EXIT_FAILURE;

	}

	// Read line-wise
	std::string line, attribute;
	bool error = false;
	while (std::getline(infilestream, line)) {

		std::istringstream iss(line);

		// Split at comma
		std::vector<std::string> attributes;
		int number = 0;
	    while (std::getline(iss, attribute, ',')) {

	        attributes.push_back(trim(attribute));
			number++;

	    }
		assert (number > 0);

		// Verify split
		if (numberOfAttributes == 0) {

			numberOfAttributes = number;

			if (class_attribute_is_last) {
				class_attribute_pos = number - 1;
			}

			if (class_attribute_pos >= numberOfAttributes) {

				error = true;
				std::cerr << "Position for class attribute is larger than the number of attributes" << std::endl;
				break;

			}


 		} else if (!(numberOfAttributes == number)) {

			std::cerr << "Discovered a different number of atributes" << std::endl;
			break;

		}

		// Add case
		cases.push_back(attributes);

		// Try to identify the classification
		if (n_attr.compare (attributes[class_attribute_pos]) == 0) {
			negative.push_back(total_cases);
		} else if (p_attr.compare (attributes[class_attribute_pos]) == 0) {
			positive.push_back(total_cases);
		} else {

			std::cerr << "Class attribute " << attributes.at(class_attribute_pos) << " unknown (has to be " << n_attr << " or " << p_attr << ")" << std::endl;
			error = true;
			break;
			return 0;

		}

		total_cases += 1;

	}

	// Close file
	infilestream.close();

	// Check for error
	if (error) {
			return EXIT_FAILURE;
	}
	std::cout << cases.size() << " cases read (" << positive.size() << " positive, " << negative.size() << " negative)" << std::endl;


	/*
	 * Draw implications
	 */
	int number_of_simple_implications = total_cases * (((float)f) / 100);
	std::vector<int> pos_impl, neg_impl;
	std::set<std::pair<int, int> > implications;

	// Simple implications
	std::cout << "Drawing simple implications ...";
	draw_simple_implications(positive, negative, implications, pos_impl, neg_impl, number_of_simple_implications, a, b, v);
	int implication_count = implications.size();
	std::cout << " done!" << std::endl;
	std::cout << implication_count << " simple implications created" << std::endl; 
	std::cout << (positive.size() + negative.size()) << " remaining classified cases (" << positive.size() << " positive, " << negative.size() << " negative)" << std::endl;
	std::cout << (pos_impl.size() + neg_impl.size()) << " cases are now unclassified" << std::endl;

	// Implication chains
	int number_of_implication_chains = total_cases * (((float)g) / 100);
	if (g > 0 && l != -1) {

		std::cout << "Drawing + => + implication chains ...";

		std::pair<int, float> pr = draw_implication_chains(positive, negative, implications, pos_impl, neg_impl, number_of_implication_chains, l, v);

		std::cout << " done!" << std::endl;
		std::cout << (implications.size() - implication_count) << " implications in chains created" << std::endl;
		std::cout << "Maximal length of chain is " << pr.first << ", avarage length is " << pr.second << std::endl;
	std::cout << (positive.size() + negative.size()) << " remaining classified cases (" << positive.size() << " positive, " << negative.size() << " negative)" << std::endl;
		std::cout << (pos_impl.size() + neg_impl.size()) << " cases are now unclassified" << std::endl;

	}

	// Check implications
	if (check_implications (cases, implications, class_attribute_pos, n_attr, p_attr)) {
		std::cout << "Implications are satisfiable" << std::endl; 
	}


	/*
	 * Write 
	 */
	std::ofstream outfilestream((std::string(filename) + ".new"), std::ios_base::out & std::ios_base::trunc);
	if (!outfilestream.is_open()) {

		std::cerr << "Unable to open output file '" << (std::string(filename) + ".new")  << "'" << std::endl;
		return EXIT_FAILURE;

	}

	// Write data
	for (std::vector<int>::iterator it = positive.begin(); it != positive.end(); it++) {
		write_case (outfilestream, cases[*it], false, class_attribute_pos, unclassified_value);
	}
	for (std::vector<int>::iterator it = negative.begin(); it != negative.end(); it++) {
		write_case (outfilestream, cases[*it], false, class_attribute_pos, unclassified_value);
	}
	for (std::vector<int>::iterator it = pos_impl.begin(); it != pos_impl.end(); it++) {
		write_case (outfilestream, cases[*it], true, class_attribute_pos, unclassified_value);
	}
	for (std::vector<int>::iterator it = neg_impl.begin(); it != neg_impl.end(); it++) {
		write_case (outfilestream, cases[*it], true, class_attribute_pos, unclassified_value);
	}

	outfilestream.close();


	// Write implications
	outfilestream.open((std::string(filename) + ".implications"), std::ios_base::out & std::ios_base::trunc);
	if (!outfilestream.is_open()) {

		std::cerr << "Unable to open output file '" << (std::string(filename) + ".new")  << "'" << std::endl;
		return EXIT_FAILURE;

	}

	for (std::set<std::pair<int, int> >::iterator it = implications.begin(); it != implications.end(); it++) {
		outfilestream << it->first << " " << it->second << std::endl;
	}

	
	outfilestream.close();


	return 0;

}
