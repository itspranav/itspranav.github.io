#include <ostream>
#include <cstring>
#include <string>
#include <sstream>

extern "C" {
#include "defns.i"
#include "extern.i"

#include "tree_serializer.h"
}

/**
 * Translates a C5 decision tree into a JSON serialization.
 *
 * @param t The C5 decision tree to serialize
 * @param out An output stream to serialize to
 */
void _serialize_to_JSON (Tree t, std::ostream & out) {

	// We can only handle continuous attributes
	assert (!t->NodeType || (t->NodeType == BrThresh && Continuous (t->Tested)));
	
	// Start of class
	out << "{";

	// Inner node
	if (t->NodeType) {

		// We can only handle two branches
		assert (t->Forks == 3);

		// Attribute
		out << "\"attribute\":\"" << AttName[t->Tested] << "\",";

		// Cut
		char some_char_array[20];
		CValToStr(t->Cut, t->Tested, some_char_array);
		out << "\"cut\":" << some_char_array << ",";

		// Classification
		out << "\"classification\":0,";

		// Left
		out << "\"left\":";
		_serialize_to_JSON (t->Branch[2], out);

		// Right
		out << ",\"right\":";
		_serialize_to_JSON (t->Branch[3], out);

		// IsLeaf
		out << ",\"isLeaf\":false";

	}

	// Leaf node
	else {

		// Attribute
		out << "\"attribute\":\"\",";

		// Cut
		out << "\"cut\":0,";

		// Classification
		out << "\"classification\":" << ClassName[t->Leaf] << ",";

		// Left
		out << "\"left\":null,";

		// Right
		out << "\"right\":null,";

		// IsLeaf
		out << "\"isLeaf\":true";

	}

	// End of class
	out << "}";

}

char * serialize_to_JSON (Tree t) {

	std::stringstream out;
	_serialize_to_JSON (t, out);

	std::string str = out.str ();
	char * cstr = (char *) malloc ((str.length ()+1) * sizeof(char));
  	std::strcpy (cstr, str.c_str ());

	return cstr;

}


