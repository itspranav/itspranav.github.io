#ifndef __FILE_TOOLS_H__
#define __FILE_TOOLS_H__

#include "cmap.h"

/*
 * Reads implications from a file. The file is given as
 * as a string (\0 terminated). The return value is a
 * boolean indicating whether the operation was successful.
 *
 * The format is simple:
 * - Each line defines an implication of the form int int
 *   (separated by a blank)
 * - A line starting with # is ignored
 */
int read_implications(const char *, struct cmap *);

#endif
