void __VERIFIER_assert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}
int __VERIFIER_nondet_int();

main()
{
  unsigned int N_LIN = __VERIFIER_nondet_int();
  unsigned int N_COL = __VERIFIER_nondet_int();      
  unsigned int j,k;
  int v1, v2, v3;
  int matriz[N_COL][N_LIN], maior;
  
  maior = __VERIFIER_nondet_int();
  for(j=0;j<N_COL;j++)
    //invariant matriz[0][0] <= m || j <= 0;	
    for(k=0;k<N_LIN;k++)
    {       
       //assert b1(maior,matriz[0][0],j,k);	
       matriz[j][k] = __VERIFIER_nondet_int();
       
       if(matriz[j][k]>=maior)
          maior = matriz[j][k];                          

       v1 = __VERIFIER_nondet_int();
       v2 = __VERIFIER_nondet_int();
       v3 = __VERIFIER_nondet_int();
    }                       
    
  __VERIFIER_assert(matriz[0][0]<=maior);    
}

