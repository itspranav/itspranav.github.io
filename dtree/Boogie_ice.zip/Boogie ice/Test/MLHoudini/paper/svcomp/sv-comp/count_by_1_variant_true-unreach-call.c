#include "assert.h"

void main() {
    int i;
    for (i = 0; i != 100; i++) {
	__VERIFIER_assert(i <= 100);
    }
}
