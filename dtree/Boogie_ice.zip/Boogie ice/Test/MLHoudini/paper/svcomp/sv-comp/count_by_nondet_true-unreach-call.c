#include "assert.h"
void main() {
    int i = 0;
    int k = 0;
    while(i < 100) {
	int j = __VERIFIER_nondet_int();
	__VERIFIER_assume(1 <= j && j < 100);
	i = i + j;
	k ++;
    }
    __VERIFIER_assert(k <= 100);
}
